# SponsorScout — Codebase Guide & Agent Handbook

> **Purpose of this document.** SponsorScout is a career-portal job scanner with
> sponsorship-evidence detection. This guide is the handoff artifact for any
> developer or AI agent that needs to fix bugs, extend coverage, or review scan
> output. It describes the architecture, the contracts, and the gotchas that have
> caused real bugs. Read §10 (bug-fix workflow) and §12 (gotchas) before touching code.

**Last verified:** build 2026-10-22 (**v0.2.0**, desktop release). The desktop app
has **eight tabs**: Dashboard, Search, Applications, Tools, Data Management,
AI Prompt Kit (AI Tailoring), Insights, and Assisted Ingestion. **Test state** (`python3 -m pytest sponsorscout/tests -q`, offscreen
Qt): **571 passed, 0 failed, 4 skipped** (Chromium installed in the sandbox).
Repo-root mirror suites `tests/test_run20261016_fixes.py` **61/0** and
`tests/test_run20261016B_fixes.py` **62/0** (5 checks skip). `tools/check_readme_anchors.py`
**52/52**.

---

## 1. What SponsorScout does

Given a CSV of seed companies + career-page URLs, it:

1. crawls each seed's job board (provider API → static HTML → browser fallback),
2. validates every candidate row (URL shape, title quality, scope),
3. runs **sponsorship-evidence detection** on job descriptions (tri-state: Yes /
   No / Unknown — never guess),
4. deduplicates across URL variants, seeds, and buckets,
5. writes `career_jobs.csv` (+ quarantine / scan log / errors / baseline) and
   ingests into a SQLite DB for the PySide6 desktop app.

Sponsorship-relevant columns (`Visa Sponsorship`, `Relocation Support`,
`Support Evidence`, `Support Evidence Type`, `EU Blue Card`, …) are the product.
**A wrong "No" is worse than "Unknown".** The detector contract (§6) is binding.

### Desktop app — eight tabs

| Tab | Purpose |
|---|---|
| Dashboard | KPIs, top sponsoring companies, jobs by country |
| Search | Filter, sort and page through scanned jobs; right-click to open or save to Applications |
| Applications | Pipeline tracker: Saved → Applied → Interview → Offer → Rejected, with notes |
| Tools | Scan Now / Custom Scan, live log, scan history, data quality, freshness check |
| Data Management | Edit the ATS and career seed lists |
| AI Prompt Kit | Build one paste-ready message for an AI chatbot: job description + AI prompt + CV + cover letter |
| Insights | Aggregated intelligence: functional category, skill (technical & soft), employer domain, and sponsorship distribution with interactive slice cross-filtering |
| Assisted Ingestion | Headful interactive browser for human-verification challenges and full multi-page vacancy harvesting |

---

## 2. Quickstart for an agent

```bash
cd <repo root>

# Repo-root mirror suites (plain python, offline, no pytest needed):
python3 tests/test_run20261016_fixes.py     # expect: 61 PASS / 0 FAIL
python3 tests/test_run20261016B_fixes.py    # expect: 62 PASS / 0 FAIL

# The core install-side suites (run these first and last):
python3 -m pytest sponsorscout/tests/test_sponsorship_detection.py \
    sponsorscout/tests/test_regressions.py \
    sponsorscout/tests/test_pipeline.py -q

# Full suite (needs --continue-on-collection-errors; PySide6 missing in CI):
python3 -m pytest --continue-on-collection-errors -q

# Detector ML eval (informational — exits 0 by design, prints mismatches):
python3 tools/ml_eval.py   # 79/98 at v0.2.0; do NOT "fix" jd_support for it

# Standalone scan (no desktop app) — the way to LIVE-VERIFY a fix:
python3 -m sponsorscout.scanning.career.career_scanner \
    --input sponsorscout/data/seeds/company_Career_seed.csv --output out/verify_jobs.csv \
    --skip-preflight --company "Elior Italia" --company "Leroy Merlin Italia"

# Regression pins for the 2026-10-22..23 fix rounds (F-27…F-40):
python3 -m pytest sponsorscout/tests/test_harvest_consistency_2026_10_22.py -q   # 103 pins
python3 -m pytest sponsorscout/tests/test_assisted_completeness_2026_10_22.py -q # 9 pins
python3 -m pytest sponsorscout/tests/test_tick_indicator_2026_10_22.py -q        # 4 pins

# Live verification of assisted/anti-bot pagination (shipped alongside the
# repo in the fixes archive): synthetic signed-pager board + 8-phase harness:
python3 live_verify/live_verify_synth.py    # phases A–H, prints RESULT: PASS
python3 live_verify/live_verify_deep.py     # 27-page board, 270 jobs
```

**Baseline expectation (rev 13, 2026-10-23):** `python3 -m pytest sponsorscout/tests -q
--continue-on-collection-errors` shows **681 passed, 12 failed, 4 skipped**. The
12 failures + 4 skips are the pre-existing set documented in `FIXES_MANIFEST.md`
(shipped with the fixes archive); none was introduced by fixes F-01…F-40
(pre-engagement baseline: 560 passed / 15 failed / 6 skipped). The older
2026-10-19 baseline (571/4/0) and the 2026-10-17 nine-failure list below are
kept for history only:

- `test_experience.py::test_multilingual_non_experience_durations_rejected`
- `test_i18n_parity.py::test_every_ui_key_has_italian_translation` (missing keys:
  `DNS re-crawl: %s host(s) recovering`, `Run:`)
- `test_playwright_health.py::test_reason_is_surfaced_in_the_raised_error`
- `test_regressions_2026_02.py` — `test_a2g_seed_is_scoped_global`,
  `test_seed_repair_converges_every_historical_a2g_value`,
  `test_seed_repair_never_clobbers_a_deliberate_user_edit`
- `test_scan_controls.py::test_sleep_interruptible_sleeps_through_when_idle`
- `test_search_tab.py` — `test_header_sort_orders_data_and_keeps_columns_aligned`,
  `test_clipped_tooltip_never_survives_a_page_change`

Any failure outside this list is a regression. Use the test run's own output as the
baseline, not an older saved file. GUI tests need the Qt system libraries
(`libxkbcommon0`, `libnspr4`, `libnss3`; `ImportError: libxkbcommon.so.0` means they
are missing). Playwright tests need `python3 -m playwright install chromium`, plus
`python3 -m playwright install-deps chromium` for its system libraries (`libatk-1.0.so.0` missing
makes the browser test skip with `TargetClosedError`).

**Deliverable:** the repository itself (GitHub). Version lives ONLY in
`pyproject.toml` (**0.2.0**) — `installer.iss` carries the same default and
`build_deb.sh` / `build_rpm.sh` / `build_exe.ps1` all derive from pyproject. Every
user-facing change gets a changelog entry; release installers are built by the root
scripts.

---

## 3. Repository layout

```
<repo root>
├── assets/                       # README screenshots (incl. AI_tailoring_setup.png)
├── sponsorscout/                 # the Python package (tree below)
├── tests/                        # run-fix mirror suites (plain python, offline) + seed/zip helpers
├── tools/                        # check_readme_anchors.py, find_dead_code.py (+ .allow),
│                                 #   ml_eval.py, SponsorScout_codebase_guide.md (this file)
├── build_deb.sh, build_rpm.sh    # release installers (LF)
├── build_exe.ps1                 # Windows installer build (CRLF)
├── installer.iss, SponsorScout.spec   # Inno Setup + PyInstaller definitions
├── pyproject.toml, requirements.txt   # version single-source = pyproject.toml
├── README.md                     # product readme (English + Italiano)
├── INSTALL.txt, MANIFEST.in, LICENSE
└── .clineignore, .editorconfig, .gitattributes, .gitignore
```

The bundled seed CSVs live in `sponsorscout/data/seeds/`
(`company_Career_seed.csv`, `company_ATS_seed.csv`, `remote_seed.csv`).

Regression pins for the 2026-10-22…23 rounds live in
`sponsorscout/tests/test_harvest_consistency_2026_10_22.py` (103 pins, F-27…F-40),
`test_assisted_completeness_2026_10_22.py` (9) and
`test_tick_indicator_2026_10_22.py` (4). The native checkbox tick is a pure-QSS
asset pair: `sponsorscout/data/icons/tick.png` + `tools/make_tick_icon.py`.
Shipped **alongside** the repo in the fixes archive: `live_verify/synth_board.py`,
`live_verify/live_verify_synth.py` (8-phase harness), `live_verify/live_verify_deep.py`
and `FIXES_MANIFEST.md` (fix register F-01…F-40, delivery revisions 1–14).

```
sponsorscout/
├── __init__.py, main.py, paths.py, i18n.py   # entry point, paths, translations
├── application/
│   ├── scan_coordinator.py                   # app-level scan orchestration
│   └── seed_manager.py                       # user seed paths, read_seed_rows()
├── core/                                     # shared logic: ats_detection, dedup, http_client,
│                                             #   integrity, location_country, normalizer,
│                                             #   persistence, url_normalizer, verification,
│                                             #   verification_service
├── data/                                     # seeds/ (bundled CSVs), icon and profile data
├── db/                                       # database.py (SQLite access), schema.sql
├── models/job.py                             # job record shape
├── scanning/
│   ├── pipeline.py                           # run_scan(): ATS phase → career phase → DB ingest
│   ├── common.py                             # shared crawl utilities
│   ├── jd_support.py                         # sponsorship detector (JDSupportDetector)
│   ├── ats/ats_scanner.py                    # ATS job-board scanner
│   └── career/career_scanner.py              # ★ THE MONOLITH (~13.9k lines). Read on.
├── scripts/                                  # run_scan.py (CLI), backfill_industry.py
├── services/browser_fetcher.py               # Playwright wrapper (browser path)
├── ui/
│   ├── app.py, style.py                      # main window and styling
│   └── tabs/                                 # applications, assisted, dashboard, data_management,
│                                             #   insights, search, tailoring, tools
├── insights/                                 # terms.py (classifier/extractor), queries.py (aggregations)
└── tests/                                    # all pytest suites live HERE
```

**Desktop-only tables (2026-10-17).** `applications` (saved pipeline rows, keyed by
`job_url`) and `tailoring_documents` (`kind` = `ai_prompt` | `cv` | `cover_letter`,
one row each, defined in `db/schema.sql`). The job description is **never** stored
in `tailoring_documents`; it is session-only by design.

---

## 4. Scanner anatomy and data flow

**`career_scanner.py` is the center of gravity.** The names below are verified
against the 2026-10-17 tree.

| Layer | Names |
|---|---|
| Config | `ProductionScannerConfig` (class attrs: `ROLE_WORD_PATTERN`, `URL_EXCLUSION_PATTERN`, `CATEGORY_PATH_INDICATORS`, `MAX_DETAIL_SCAN_TOTAL`, `DETAIL_MIN_PER_COMPANY`, `MAX_PAGINATION_PAGES`, …) |
| Scanner | `CareerPortalScanner` (`execute_crawler()`) |
| Per-row | `crawl_target()` → `process_job()` (closure inside `execute_crawler`) |
| Provider APIs | `_fetch_provider_jobs(target_row)` → `_fetch_workday_jobs`, `_fetch_smartrecruiters_jobs`, `_fetch_teamtailor_jobs`, `_fetch_oracle_jobs`, `_fetch_bamboohr_jobs`, `_fetch_icims_jobs`, `_fetch_eightfold_jobs`, `_fetch_jobsinnetwork_jobs`, `_fetch_pam_jobs`, `_fetch_digitalrecruiters_jobs`, `_fetch_avature_jobs`; `_fetch_one`, `_fetch_jd_text` |
| Static HTML | `fetch_static_jobs(seed_url, timeout_sec, min_jobs, url_validator, title_validator)` — relative links resolved with `urljoin` against the page URL, empty-title → slug rescue, static pagination (`SPONSORSCOUT_STATIC_MAX_PAGES`), `_direct_listing_pagination_state()` for load-more controls, `_parse_static_anchors()`, `_StaticAnchorParser` |
| Structured data | `extract_embedded_json_jobs()` |
| Browser | DOM heuristics + in-page extractors (`looksJobUrl`, `jobUrlRe`, `badUrlRe` inside JS strings), `_DeadEndBoard`, `GOTO_RETRIES`, `progressive_scroll_and_wait()` (one jump to the bottom; the four-step walk runs only when the page grows) |
| Validation | `is_valid_job_url()`, `is_valid_job_title()`, `clean_and_normalize_url()`, `is_category_facet_url()`, `is_self_listing_url()`, `has_job_identifier_query()` |
| Title rescue | `_title_from_url_slug()` (TWO copies: module-level + class static — keep in sync!), `_recover_anchor_title()`, `_static_attr_title()`, `_title_from_detail_page()` (reads `<h1>`, then `<title>`, then the first three non-section `<h2>`s; every candidate still goes through `is_valid_job_title`), `clean_job_title()` |
| Location | `_location_from_detail_header()`, `_location_from_title_text()` |
| Evidence | `_enrich_support_from_detail()` (chunked fetches + early stop), `_apply_support_from_text()` |
| Dedupe | `_dedupe_cross_bucket()`, `_dedupe_same_url_across_seeds()`, `_frag_twin_in_index()` |
| Detector | `JDSupportDetector` in `scanning/jd_support.py` — call `det.detect(text)[kind]` |

### Pipeline order (do not reorder casually)

```
seed CSV (seed_manager.user_career_path())
  └─ CareerPortalScanner.execute_crawler()
       per seed (crawl_target):
         1. _fetch_provider_jobs  → provider adapters, chosen by the seed's provider
         2. static HTML  → fetch_static_jobs (identical validators,
            static bytes; min-jobs gate falls back to browser)
         3. browser fallback → Playwright DOM extraction (GOTO_RETRIES,
            _DeadEndBoard / SPONSORSCOUT_DEAD_END_SEC)
         per row (process_job):
           clean_and_normalize_url → is_valid_job_url → is_self_listing_url
           → clean_job_title → [title rescue chain] → is_valid_job_title
           → location parse → scope check → detector → record build
       after all seeds:
         _dedupe_cross_bucket            # direct-vs-recruiter copies
         _dedupe_same_url_across_seeds   # same vacancy, 2+ seeds → SOURCE MERGE
         regression gate (vs baseline.json)
       outputs: *_career_jobs.csv, *_career_jobs_recruiter.csv, *_quarantine.csv,
                *_scan_log.csv, *_errors.csv, *_baseline.json
```

**Politeness/human-like delays are intentional. Never remove them to "go faster".**
Speed fixes must come from early-stops, budgets, caching, and parallelism
oversubscription control (`recommended_workers("http"|"browser")`; host-tier sizing,
capability-detected only).

---

## 5. Output files & schemas

Files are written per run with a run-ID timestamp prefix (the run ID is also stored in the `Run ID` column) (e.g.
`20261017T171714_career_jobs.csv`). **All CSVs have BOM headers — read them with
`encoding="utf-8-sig"` and write with the same.**

`career_jobs.csv` columns (main ones):
`Company Name, Seed Name, Source Type, Hiring Company, Target Country, Scope
Policy, Industry Type, Sponsorship History Score, English Friendly Score, Remote
Score, Job Title, Raw Job Title, Job Location, Raw Location, Job Type, Job URL,
Canonical Job ID, Provider, Extraction Method, EU Blue Card, Blue Card Evidence,
Relocation/Visa Support, Work Mode, Scope Confidence, Experience Required,
Experience Min Years, Experience Level, Experience Source, Location Source,
Location Confidence, URL Type, Visa Sponsorship, Relocation Support, Relocation
Required, Support Confidence, Support Evidence, Support Evidence URL, Support
Evidence Type, Record Status, Quarantine Reason, Run ID, Scanned At`

- `Extraction Method` values in code: `static_html`, `direct_listing_anchor`,
  `embedded_json`, `avature_html`, and the provider labels `workday_api`,
  `smartrecruiters_api`, `teamtailor_api`, `oracle_api`, `bamboohr_api`,
  `icims_api`, `eightfold_api`, `jobsinnetwork_api`, `pam_api`,
  `digitalrecruiters_api`, `greenhouse_api`, `lever_api`, `ashby_api`,
  `personio_api`, `recruitee_api`, `workable_api`.
- `URL Type`: `real` | `synthetic` (fragment-identified `#job=` rows are
  *legitimate* synthetic — see §12).
- Merged cross-seed rows carry `Seed Name` like `"Seed A; Seed B"`.

`*_quarantine.csv` — same columns; `Record Status=quarantine` + reason:

| Reason | Meaning |
|---|---|
| `invalid_or_application_only_url` | URL is nav/apply/marketing (or non-job host) |
| `category_or_department_link` | facet/chip link, not a posting |
| `self_listing_url` | link points at the seed page itself |
| `invalid_generic_or_department_title` | title is boilerplate/department/garbage |
| `duplicate_url_variant` | same job, second URL shape (same seed) |
| `duplicate_url_cross_seed` / `duplicate_url_cross_source` | cross-seed or cross-source duplicate reasons carried over from earlier runs; the current cross-seed pass MERGES instead, see §7 |

`*_scan_log.csv`: `Run ID, Seed Name, Company, Source Type, Target Country,
Status(ok|empty|error), Provider, Jobs Found, Quarantined, Duplicates, Rejected
Scope, Error, Diagnostics, Duration Sec, Seed URL`. **Read `Diagnostics` in full
before concluding anything — it carries the per-seed story** (e.g. `static HTML: N (P page(s))`,
`provider adapter not configured`, `static: fetch failed (HTTPError)`,
`pagination complete: no next-page control after page 1`).

`*_baseline.json`: per-seed `counts` for the regression gate (alerts when a
company collapses ≥80% vs the previous run).

**Seed CSV** (`company_Career_seed.csv`, header):
`name, careers_url, provider, board_slug, source_type, target_country, scope_policy,
industry, sponsorship_history, english_friendly, remote_score, notes`.
`#`-prefixed rows are group comments.
`source_type` ∈ `direct_employer` | `recruiter` — recruiter rows are MERGED into
the main jobs.csv with the source marker (never a separate `_recruiter.csv`).

---

### Assisted-run log set (F-36, round 10)
An assisted (anti-bot) run writes the **same five-CSV set** a regular scan
writes, all `utf-8-sig`: `{run}_career_jobs.csv`, `{run}_career_jobs_recruiter.csv`
(the recruiter-sourced subset; identical to the main file when every row is
recruiter-sourced), `{run}_career_jobs_quarantine.csv`,
`{run}_career_jobs_errors.csv` and `{run}_career_jobs_scan_log.csv` (Key/Value
summary, per-seed row with Diagnostics, then the event timeline). The run is
also recorded in `scan_runs`, `scan_log` and `scan_events`. Row timestamps use
the run's UTC clock and a real calendar day (`%Y-%m-%d`, F-39 — an earlier
`%Y-%m-%m` format wrote the month twice and no day).

## 6. Detector contract (binding)

Implemented in `scanning/jd_support.py` (`JDSupportDetector.detect(text)` returns
a dict keyed by kind; consume via `det.detect(text)[kind]`).

- **Tri-state everywhere:** `Unknown ≠ No`. Absence of evidence is never refusal.
- Hedged offer ("may sponsor") ≠ refusal. Speculative offer ("could sponsor") ≠ offer.
- Negated problem ("no visa issues") ≠ refusal.
- Support Evidence Type ∈ `explicit_detail_sentence` | `none` — evidence must be
  a real sentence from the JD (with `Support Evidence URL` when a page backs it).
- FP guard rails: `SUPPORT_GUARD_HITS` counts downgrades (audited in scan output).
- `EU Blue Card = Unknown` for all rows is normal when JDs say nothing about it.

---

## 7. Validation & dedupe — exact order matters

`is_valid_job_url` (fix order preserved deliberately — later rescues beat earlier
exclusions):

1. http check, social/app-host blocks, root-page rule
2. account/marketing path, asset/download, ATS furniture, apply-path rule
3. **job-id rescues — BEFORE the path exclusion** (`#job=` fragment,
   `has_job_identifier_query()`, path job-id `/(?:jobs?|…)/[^?#]*\d{6,}`):
   careers hosted under `/about/` paths would otherwise be killed by the
   `URL_EXCLUSION_PATTERN` "/about" term. **Do not reorder.**
4. `URL_EXCLUSION_PATTERN` scoped to `_parsed.path` only (never host/full URL)
5. category/facet rules (`is_category_facet_url`), then accept patterns

`process_job` title chain:
`clean_job_title` → `is_valid_job_title` fails → `_title_from_url_slug` (slug-only
rescue, no fetch) → for invalid titles only: `_title_from_detail_page` (ONE budgeted
fetch) → else quarantine `invalid_generic_or_department_title`.

Dedupe layers (run in this order at end of `execute_crawler`):

1. `_dedupe_cross_bucket(output_csv, quarantine_csv, columns)` — direct vs
   recruiter copies of one posting.
2. `_dedupe_same_url_across_seeds(path, quarantine_csv, columns)` — same vacancy
   under 2+ seeds (different Company Name). This MERGES the source into the kept
   row's `Seed Name` (`"Seed A; Seed B"`) and quarantines NOTHING. Keys on
   `host|num:<id>` when the URL has a numeric id, else `host|url`.
3. In-memory guards during crawl: `_frag_twin_in_index` (`#job=` vs clean-URL
   twins), same-URL seen-set.

`_title_from_url_slug` exists in **two copies** (module function + class
staticmethod with slightly different internals). Both strip leading AND trailing
pure-digit tokens (≥4 digits) from `<digits>-<words>` hybrid slug segments.
Change one → change the other.

---

## 8. Environment knobs

Every knob below is read in code; defaults shown are the code defaults where one exists.

| Knob | Default | Effect |
|---|---|---|
| `SPONSORSCOUT_WORKDAY_DETAILS` | 150 | Workday JD fetch budget per seed |
| `SPONSORSCOUT_SMARTRECRUITERS_DETAILS` | 150 | SmartRecruiters detail budget |
| `SPONSORSCOUT_BAMBOOHR_DETAILS` | 150 | BambooHR detail budget |
| `SPONSORSCOUT_DIGITALRECRUITERS_DETAILS` | 150 | Digital Recruiters detail budget |
| `SPONSORSCOUT_JOBSINNETWORK_MAX` | 600 | JobsInNetwork row cap |
| `SPONSORSCOUT_AVATURE_PAGES` | 40 | Avature listing page cap |
| `SPONSORSCOUT_DETAIL_TOTAL` | — | global detail-page fetch cap (`MAX_DETAIL_SCAN_TOTAL`) |
| `SPONSORSCOUT_DETAIL_PER_COMPANY` / `SPONSORSCOUT_DETAIL_FLOOR` | — | per-seed detail budget + reserved floor |
| `SPONSORSCOUT_DETAIL_BUDGET` / `SPONSORSCOUT_DETAIL_SCAN` | — / 1 | detail-pass budget / detail-scan toggle |
| `SPONSORSCOUT_DETAIL_BODY_MIN` | — | min body size for a detail page to count |
| `SPONSORSCOUT_LIST_BUDGET` | 300s | per-seed LIST pagination wall budget |
| `SPONSORSCOUT_SCOPE_BROWSER_MAX` / `_BUDGET` | — | scope re-check browser pass |
| `SPONSORSCOUT_SCOPE_FILTER` | 0 | scope policy selector |
| `SPONSORSCOUT_SCOPE_RESOLVE_MAX` / `SPONSORSCOUT_LOC_RESOLVE_MAX` | — | scope and location resolver budgets |
| `SPONSORSCOUT_STATIC_MAX_PAGES` | 12 | static pagination follow cap |
| `SPONSORSCOUT_LISTING_CHECK_MAX` | — | listing-shape probe budget |
| `SPONSORSCOUT_TITLE_RESCUE_MAX` / `_PER_COMPANY` | — | title-rescue fetch budget |
| `SPONSORSCOUT_HTTP_WORKERS` / `SPONSORSCOUT_MAX_WORKERS` | host-sized | worker pools (capability-detected; do not hardcode) |
| `SPONSORSCOUT_DEAD_END_SEC` | — | dead-board abort (`_DeadEndBoard`) |
| `SPONSORSCOUT_PROVIDER_SNIFF` | 1 | provider probing toggle |
| `SPONSORSCOUT_DATA_DIR` / `SPONSORSCOUT_DB_PATH` | — | storage |
| `SPONSORSCOUT_AUTO_INSTALL_BROWSERS` | — | Playwright install |

---

## 9. Testing conventions

- **Install-side suites live in `sponsorscout/tests/`.** The repo-root `tests/`
  holds the run-fix **mirror suites** (`test_run20261016_fixes.py` 61 checks,
  `test_run20261016B_fixes.py` 62 checks) — plain-python, offline, run with
  `python3 tests/<file>.py`. Helpers there: `build_zip.py`, `make_bad_portals_seed.py`,
  `make_test_seed.py`, `validate_bad_portals_seed.py`, `verify_rebase.py`.
- The core suites: `test_sponsorship_detection.py`, `test_regressions.py`,
  `test_pipeline.py`. The full suite adds UI/i18n/db/experience/static-paging/tailoring
  and other suites (see `sponsorscout/tests/`).
- **Every production fix ships with a pin** in `sponsorscout/tests/`, ideally as a
  `Test…` class named after the change. The 2026-10-17 static-paging fixes are pinned in
  `test_static_paging_2026_10_17.py`; the AI Tailoring pins are in `test_tailoring_2026_10_17.py`.
- Synthetic fixtures only in development — the user may *supply* run batches for
  review (those reads are sanctioned); never build fixtures from them.
- Live-scan pins that need a network seam: pass a stubbed `urlopen` (see
  `test_static_paging_2026_10_17.py`); `_fetch_jd_text` is the seam for JD fetch passes.
- Scanner unit stubs need `sc.config = ProductionScannerConfig()`, plus
  `sc.KNOWN_PLACES`, `sc.NORM_KNOWN`, `sc.COUNTRY_CODES` (for URL/title validators),
  `sc.detector = JDSupportDetector()` (evidence), and `sc._detail_lock`,
  `sc._detail_count` (detail passes).
- Quarantine CSVs in tests must be **pre-created with a header row** (production
  appends without header).
- `pipeline._row_to_job` is the row→DB conversion; call it directly in tests
  (don't boot the pipeline). `_fetch_workday_jobs` raises → test via
  `_fetch_provider_jobs`.
- The ROLE_WORD pattern is `ProductionScannerConfig.ROLE_WORD_PATTERN` (the validator
  reads `self.config.ROLE_WORD_PATTERN`); the scanner class has no such attribute.

---

## 10. Bug-fix workflow

The user's standing complaint: *"running the same test again and again, getting
bugs each time."* Root cause was shipping after unit tests only. The process
below is mandatory:

1. **Reproduce from the user's run artifact** (uploads CSVs, utf-8-sig). Build a
   per-company truth table: rows found vs CSV rows vs quarantined vs dups vs
   runtime vs diagnostics.
2. **Classify**: regression vs fix-not-landed vs known limitation vs data gap.
3. **Write the failing pin first** (synthetic), then fix, then pin green.
4. **Replay the fix against the real run rows** (offline script on the uploaded
   CSV) and show before/after counts.
5. **LIVE-VERIFY**: run the standalone scanner on the affected seeds
   (`python3 -m sponsorscout.scanning.career.career_scanner --input … --company …`).
   Static/API seeds work without Playwright; browser-path seeds need the user's
   environment (say so honestly).
6. **Gates**: core suites + full suite against the pre-existing failure list in §2,
   plus the repo-root mirror suites and `tools/check_readme_anchors.py`.
7. **Commit**: changelog entry (+ version bump in `pyproject.toml` and `installer.iss`
   when a release is cut); releases build via root scripts.
8. **Report honestly**: what is proven, what remains (never claim "that's it"
   without step 5 evidence).

When reviewing a run, always sweep **every company** (not only the one the user
named): per-seed found/CSV/q/dup/runtime, URL health (doubled query params,
stray dots, apply paths), title health (noise, employer-as-title, lowercase),
cross-seed overlaps, and field-level sanity.

---

## 11. Where things live in the run output — triage map

| Symptom | First place to look |
|---|---|
| Seed = 0 rows | `_scan_log` Diagnostics: `static: only N job link(s) (<5); using browser` (JS shell?), `provider adapter not configured`, `static: fetch failed (HTTPError)`, bot wall (`_errors.csv`) |
| Seed found N but CSV < N | cross-seed merge (Seed Name has `;`) or dedupe folds — check `Duplicates` + quarantine |
| Rows look duplicated | fragment twins → `_frag_twin_in_index`; direct vs recruiter copies → `_dedupe_cross_bucket`; cross-seed → `_dedupe_same_url_across_seeds` (merged, not dropped) |
| Garbage title in output | `is_valid_job_title` / `clean_job_title` missed the phrase, or a title with no role word and no slug rescue |
| Garbage row in quarantine (false reject) | URL exclusion hit host not path; rescue ran after exclusion (see §7 order); role word missing from `ROLE_WORD_PATTERN` |
| Seed is slow | per-row fetch passes without early-stop (§12); `Diagnostics` counts fetched vs enriched; detail/evidence pass budgets |
| Empty evidence column | expected for card-only rows; only rows with JD text get verdicts |
| Missing locations | `Location Source` values tell the story (`api`, `card`, `detail`, `none`) |

---

## 12. Hard-won gotchas (do not re-learn these)

1. **BOM headers** — every CSV: `utf-8-sig` for read AND write.
2. **Tests live in `sponsorscout/tests/`** — the repo-root `tests/` holds only the mirror suites and seed/zip helpers.
3. **`ROLE_WORD_PATTERN` lives on `ProductionScannerConfig`**, not the scanner.
4. **`_title_from_url_slug(url)` takes no self** and exists in TWO copies.
5. **Full pytest needs `--continue-on-collection-errors`** (PySide6 absent in CI).
6. **Careers under `/about/` paths** — path exclusions must not outrank job-id rescues; `#job=` URLs are REAL rows (`URL Type=synthetic`).
7. **Cross-seed duplicates are MERGED (source marker in Seed Name), not quarantined** — the user explicitly rejected the quarantine flood.
8. **Evergreen/pipeline postings stay ACCEPTED** — "(Evergreen)", "(Future Opportunities)", "Spontaneous Application" rows must NOT be quarantined. Only true noise (nav/marketing/legal/content pages) and garbage titles.
9. **JS shells** (sites whose raw HTML contains zero job links) cannot be fixed by static regex; they need JS-state/API discovery or the browser path.
10. **Per-row fetch passes need dead-end early stops** (25 consecutive empty results). Any new fetch loop ships with chunked submission + a miss counter.
11. **Detail-evidence fetches are silent in `_scan_log` Diagnostics** — if a seed is mysteriously slow, look for the `Support detection […] (N fetched)` and `Experience backfill` console lines.
12. **Use `PySide6-Essentials`, not `PySide6`.** The meta-package pulls WebEngine, Addons and PDF wheels the app never imports (about 800 MB → 370 MB bundle difference measured). Do not add `--collect-submodules PySide6` back without re-checking size, and do not import Qt modules outside QtCore/QtGui/QtWidgets without deciding whether to remove the matching PyInstaller exclude.
13. **Politeness delays are intentional** — optimize via early-stops, budgets, cache, and host-capability sizing only. GPU/hardware acceleration stays out of the app entirely.
14. **`?page=N` boards**: follow the page's OWN hrefs via `urljoin(base_url, href)` — never synthesize `/page/N` from the seed.
15. **Relative links** in static harvest resolve with `urljoin` against the page URL. The code does not read `<base href>`; if a site relies on it, this is a known gap.
16. **User supplies run batches** (uploads `RUN_ID_*`) for review — reading those is sanctioned; everything else stays synthetic in dev.
17. **A re-served listing is a REFUSED advance, not the end and not a page** (F-27/F-35c/F-37): retry with another mechanism; three refusals on a FULL page may end the run only after the cool-downs and probes below; the counter stays on the last complete page.
18. **Signed pagers accept only their own hrefs** — check 3.5 (`paging_href_candidates`) follows the board's anchors; synthesised URLs with a stale/absent page token are clamped to the visible window by such boards. Never strip signature-like params to "fix" a clamp.
19. **Cool-downs escalate and are bounded** (F-37/F-38): 15 s → 45 s → 90 s, at most three pauses per run, pure waiting, before any probe; end-of-board probes are capped at 4 loads per run, shared by both stop branches.
20. **"Pages read" ≠ browser loads** (F-34): the user-facing count is complete listing pages; retries/clamps stay visible as `loads` in log and report.
21. **Startup must stay scoped** (F-40): preflight probes only this run's hosts (parallel, warn-only); the provider sniff is ≤4 s and caches negatives — a bot-walled seed must never re-block every start.
22. **The tick indicator is pure QSS** (rev 3): white box, dark rim, dark tick, no coloured fill; `test_tick_indicator_2026_10_22.py` pins zero accent pixels on checked controls.
23. **`_dedupe_*` call sites pass the loop variable** (e.g. `self.output_csv`) — a wrong variable name silently no-ops via `FileNotFoundError → return 0` inside a swallowed try/except. Pin call-site behavior, not just the method.

---

## 13. Known limitations & deferred work (as of 2026-10-17, v0.2.0)

| Item | Status |
|---|---|
| AI Tailoring — reading a JD | Plain HTTP only, no browser fallback. A blocked, login-walled or JavaScript-only page shows a popup and the user pastes the JD. Intended behaviour |
| AI Tailoring — JD persistence | Session-only by design (user decision 2026-10-17). Prompt, CV and cover letter persist |
| AI Tailoring — copy length | No app-side limit (user decision). Some chatbots cap input size; the app does not truncate |
| Applications — activity log | Session-only. The database keeps only the latest status and note per application |
| Applications — status values | Labels are translated; stored status values (saved, applied, interview, offer, rejected) show in English |
| SuccessFactors board adapter | **Deferred** by user decision (quick-plus scope). Boards that need it stay empty until the adapter exists |
| JS-shell boards (e.g. Revolut, ING, Nestlé, TomTom-style sites) | Need browser-JSON/API discovery; no adapter in this tree |
| Board needing its own JSON endpoint (T-Systems) | Needs the site's XHR capture from the user's DevTools — not fixable blind |
| `tools/ml_eval.py` mismatches (79/98) | Informational by design (exit 0). Do NOT retune jd_support for it: the detector contract is binding |
| UI-5 | WONTFIX by user decision |
| VMware | Genuine connection-level bot wall (the connection times out) |
| Workday JD budget 150 → 300 | Optional, not done |
| `SPONSORSCOUT_LIST_BUDGET` trade-off | Completeness vs speed — raise the env var if the user wants completeness |
| `EU Blue Card` all-Unknown | Normal without JD mentions (not a bug). Assisted rows carry card text only, so visa/relocation stay Unknown there unless in-session enrichment is added later |
| Assisted-run CSV parity | **FIXED (2026-10-22, F-36)**: assisted runs write the same five-CSV set as regular scans |
| Assisted false ends / re-serve stops | **FIXED (F-35…F-38)**: probes, denied-href retries and escalating cool-downs; every stop names the last complete page |
| Scan-run row dates | **FIXED (F-39)**: `%Y-%m-%d` on the run clock |
| Slow scan start for scoped scans | **FIXED (F-40)**: scoped parallel preflight + cached sniff negatives |
| `max_pages` cap (assisted) | Default 60 per board; a 60-page board ends honestly with "page cap reached" |
| Leroy Merlin Italia (Teamtailor) | **FIXED (2026-10-17)**: 92 of 92 jobs live (was 21). Fixed by recognising the "Mostra ancora" load-more control and by reading every static page, not only page 1 |
| Visa Sponsor Jobs | Static paging reads at most `SPONSORSCOUT_STATIC_MAX_PAGES` (default 12) pages. At the default cap the 2026-10-17 run read 12 pages and wrote 350 rows in 88 s (`static HTML: 350 (12 page(s); page cap 12 reached, board has more pages)`). Raise the env var to read more; the diagnostic records when the cap is reached |
| Elior Italia seed URL | **Replaced (2026-10-17)** with the user-supplied `eliorgroup.com/career/job-offers` listing (all countries; 2,384 jobs listed). Verification run 20261017T171714 wrote 97 rows, all Italy, 5 quarantined, 30 duplicates, in 492 s |
| Robert Walters Germany | **External block (2026-10-19).** Run 20261019T195804 errored with `RuntimeError: blocked by bot protection: PerimeterX challenge page` (raised in `career_scanner.py`, bot-protection branch). The sandbox gets the same challenge over HTTP and Chromium. No bypass is implemented, and none should be added without the site's permission |
| Direct-employer rows: visa and relocation | Read as `Unknown` on most direct-employer rows. Those pages seldom state sponsorship. Signals come from the recruiter/aggregator rows |
| Tigotà seed row | Filled (2026-10-17): `direct_employer`, Italy, `seed_url`, Retail/Beauty. Its listing has not been live-verified yet |

---

## 14. Recent fix history — 2026-10-17

Entries from earlier sessions are no longer described here because the code they
named is not in this tree. Use the changelog for release history.

### v0.2.0 desktop release (2026-10-17)

- **AI Tailoring tab (new, sixth tab).** The Search tab emits `job_selected`; the
  tab shows that job. **Load JD** reads the typed URL if there is one, otherwise the
  stored job description, otherwise the job's own page. Read failures (HTTP error,
  timeout, non-HTML, under 300 characters of text) show a popup and leave the JD
  box for manual paste. Reads run on a background thread (`_JDLoader`).
  Copy = prompt + JD + CV + cover letter; the cover letter is optional and the other
  three are required (`build_clipboard_text()`). Tests:
  `sponsorscout/tests/test_tailoring_2026_10_17.py`.
- **Applications tab.** Columns fit their content on load and can be resized by
  dragging; a width the user set survives reloads. The Status cell is colour-coded
  (`STATUS_COLORS`). New **Latest notes** column. Session **Activity log** above the
  edit form. The Refresh button was removed (manual-entry tab).
- **Italian coverage.** Every new literal UI string has an Italian entry in
  `i18n.py`. Strings built from lists (for example the Applications headers) are not
  caught by the parity test, so check them by switching locale. Fixed in this
  release: "Latest notes".
- **README (EN and IT).** Five tabs → six tabs → seven tabs (Insights); AI Tailoring section with
  `assets/AI_tailoring_setup.png`.
- **Schema.** `schema.sql`: `tailoring_documents`. `database.py`:
  `get_tailoring_document`, `save_tailoring_document`, `get_job_for_tailoring`.

### Static-portal fixes P95–P99 (2026-10-17)

Found by the 12-portal test scan (`test_bad_portals_12_Career_seed_2026-10-17.csv`)
and re-verified live. All fixes are in `sponsorscout/scanning/career/career_scanner.py`.

- **P95 — card titles.** A card-style anchor wraps the whole card. The card's heading
  (`h1–h6`) and its `job-location` element are read by `_static_card_fields()`.
  `_StaticAnchorParser` keeps the anchor's inner markup (`_parse_static_anchors_full`)
  so the helper can see them. Visa: 0 long titles, 0 locations cut to "United".
- **P96 — load-more controls.** `_direct_listing_pagination_state()` recognises a
  control by its id, class or href (`show_more`, `load_more`), not only by nav text.
  "Mostra ancora" is in the click patterns. Verified in Chromium: 20→40→60→80→92.
- **P97 — static paging.** `fetch_static_jobs()` follows `rel="next"`, a show-more
  control, or next text (»/›/Next/Successiva/Mostra ancora …). It stops on a repeat
  page and at `SPONSORSCOUT_STATIC_MAX_PAGES` (default 12). The diagnostic reads
  `static HTML: N (P page(s))`.
- **P98 — navigation is not a job.** Anchors without a card heading are dropped
  when they are pager numbers or symbols, nav labels, social hosts, the homepage,
  or non-job paths (`/pages/`, `/departments/`, `-industry`, `-country`, `/terms`,
  `show_more`). Path rules match whole segments, so `/contact-center-agent` and
  `/news-anchor-jobs` are kept. Leroy: 0 non-job rows.
- **P99 — clean title attribute.** A card's `title=""` is used only when the visible
  text contains it (Leroy: "Addetto/a Casse", not "Addetto/a Casse Ancona").
- **Dead-end message** now says "since company start". The clock starts before the
  browser pass, so the old wording read as if the browser had waited that long.
- **Tests:** `sponsorscout/tests/test_static_paging_2026_10_17.py` (10 offline tests,
  stubbed `urlopen`). Suite: 379 passed, 9 pre-existing failures.
- **Live check (3 portals, 68 s, run 20261017T170803):** Leroy 92 rows (was 21),
  Visa 291 rows at the old cap of 10 pages (now 12 pages by default), Elior 0 (old
  dead URL, since replaced).

### Seed repairs (2026-10-17)

- Elior Italia: replaced the dead TalentSoft URL with the user's eliorgroup.com listing.
- Robert Walters Germany: `target_country` changed from `Global` to `Germany`.
- Tigotà: empty fields filled as a `direct_employer` Italy row.

### Live-verify harness (current seeds)

```bash
cd /home/user/codebase && python3 -m sponsorscout.scanning.career.career_scanner \
  --input sponsorscout/data/seeds/company_Career_seed.csv \
  --output /home/user/verify/verify_jobs.csv \
  --skip-preflight --company "Leroy Merlin Italia" --company "Visa Sponsor Jobs"
```

---

## 14a. Round 10c (2026-10-19)

- **Silent-empty rule extended.** `scan_personio` no longer returns `[]` when the Teamtailor fallback fails. It raises with both causes, or with the Personio cause when Teamtailor has no feed. `browser_fallback` raises `RuntimeError("browser fallback failed (...)")` after writing its errors-CSV row. It used to return `[]`. Tests: `tests/test_round10c_2026_10_19.py`.
- **Title validator.** Photographer and creative/media role nouns added to `ROLE_WORD_PATTERN`. Tests: `test_round10c_2026_10_19.py`.
- **Detail-title rescue.** `_title_from_detail_page()` tries the first three `<h2>`s after `<h1>`/`<title>`, skipping section headings ("Role Overview", "Responsibilities", ...). Work in Austria `/jobdetail/8250/cfo` now yields "CFO".
- **List-page speed.** `progressive_scroll_and_wait()` makes one jump to the bottom. The four-step walk runs only if that jump grows the page. Work in Austria, full run: 1,742 s before, 810 s after, same 1,100 rows (1,099 of 1,100 URLs identical). Tests: `tests/test_round10c_speed_2026_10_19.py`.
- **Blocked-portal prompt.** `core/blocked_portals.py` reads the career run's `*_errors.csv` after a scan finishes. It lists only rows whose message starts with the exact marker `blocked by bot protection:` (raised in `career_scanner.py` only after a real challenge page is detected). ATS artifacts are never read, and the generic "bot protection likely" guess from a plain HTTP 403 is not listed. `ui/tabs/tools.py::_offer_blocked_portals()` asks the user, then opens the URLs with `webbrowser.open_new_tab` (http/https only). The app makes no request to those sites. Tests: `tests/test_blocked_portals_2026_10_19.py` (7).
- **Build script (`build_exe.ps1`).** Native commands (pip, PyInstaller, playwright) run through `Invoke-Native` / `Invoke-NativeQuiet`, which use `Continue` and judge by exit code. Windows PowerShell 5.1 otherwise turns a pip "WARNING: Skipping PySide6 as it is not installed" into a terminating error under `Stop`. pip uninstall runs only when `pip freeze` shows PySide6. A failed `pip install -r requirements.txt` now stops the build. Verified in PowerShell 7.4.6 only, not 5.1.
- **README.** The Troubleshooting section (EN and IT) explains the bot-protection case and the scan-end prompt.
- **Leonardo.** Live Workday total 853. A fresh rescan returned 852 direct + 1 quarantined. The earlier 823–824 counts came from an earlier board state.
- **Per-company "Jobs Found" vs Search counts.** Scan log counts rows the run wrote, after its own dedupe and quarantine. Search counts database rows after filters, across runs when Run = All.

---

## 14b. Bot-protection handling & Assisted Ingestion (2026-10-20 to 2026-10-22)

- **Unattended scan contract:** Full seed scans run without blocking or interrupting the user. When a portal presents a bot-protection challenge (such as PerimeterX "Press & Hold"), the scanner identifies it (`_BOT_CHALLENGE_MARKERS`), logs `blocked by bot protection: ...` to `*_errors.csv`, and immediately moves to the next seed without stalling or raising interactive popups mid-run.
- **Post-scan in-app assisted ingestion:** When the scan completes, `ui/tabs/tools.py` presents an assisted resolution option. Alternatively, the dedicated **Assisted Ingestion** tab allows on-demand browser launching for any careers URL.
- **Headful interactive browser session:** `core/blocked_portals.run_assisted_ingestion()` launches a focused, headful browser session:
  1. The user completes the human verification challenge (e.g. Cloudflare, PerimeterX, Datadome).
  2. SponsorScout detects clearance and automatically navigates multi-page pagination across all available pages. Supports standard pagination buttons, links with `data-page`, next arrow elements (`pagination__arrow--next`), and 0-indexed (`p=0`, `p=1`, `p=2`...) as well as 1-indexed query parameter stepping.
  3. All job postings are extracted, validated (`is_valid_job_title`, `clean_job_title`, URL normalization), deduplicated, and ingested directly into the SQLite database (`jobs` table via `persistence.upsert_job()`).
  4. Automatic categorization (`category`, `domain`) and skill extraction (`job_terms`) are performed during ingestion, and the scan run is recorded into `scan_runs` and `scan_log` tables.
  5. The browser closes cleanly and newly ingested jobs appear directly in the **Search** and **Insights** tabs.

## 14c. Insights tab & Visual Market Intelligence (2026-10-22)

- **Architecture:** `ui/tabs/insights.py` backed by `insights/queries.py` and `insights/terms.py`.
- **Custom `QPainter` Visuals (no external charting dependencies):**
  - `DonutPieChart`: Side-by-side visual breakdown of **Job Roles / Functional Categories** and **Employer Industry Domains**. Slices support interactive click events (`slice_clicked`) that cross-filter the granular category bars, technical skills, soft skills, and sponsorship tables. Includes center-click / filter banner reset.
  - `ScrollableBarChart`: Horizontal bar charts hosted in scroll areas to render every single technical tool and soft skill without arbitrary truncation.
- **Interactive cross-filtering:** Query functions (`get_insights_coverage`, `get_jobs_by_category`, `get_jobs_by_domain`, `get_top_skills`, `get_segregated_skills`, `get_sponsorship_by_category`) accept `country`, `source_subtype`, `category`, and `domain` parameters.

---

## 14d. Rounds 11–14 (2026-10-22 → 2026-10-23) — revisions 10–14

- **F-31/F-32 (rev 5):** counter honesty on clamp oscillation; window-slide
  rescue for signed pagers; harness phases C/D (mid-run challenge cleared /
  never cleared).
- **F-33 (rev 6):** noise-row guards (chrome URLs, locale duplicates, CTA
  titles) and the "(page N)" dialog cap explanation (F-33b).
- **F-34…F-36 (revs 8–9):** "Pages read" = complete pages; five-branch honest
  stop messaging; assisted CSV parity with the regular workflow; real run
  clock; new-vs-duplicate counting.
- **F-35c…F-37d (revs 10–12):** mis-advance probe; clamp-at-end proof (phase
  F); one cool-down → escalating cool-downs (F-38) with phase G (soft denial)
  and phase H (six-refusal rate-limit window); denied board hrefs stay
  retryable (F-37b); the denied advance target is re-requested politely
  (F-37d). Probe budget 4 loads/run.
- **F-39 (rev 13):** scan-run Started/Finished carried the month twice and no
  day (`%Y-%m-%m`) — your exported CSVs showed 2026-10-10 for a 2026-10-23 run.
- **F-40 (rev 13):** startup de-bloated — preflight scoped to the selected
  targets' hosts and parallel in both scanners; provider sniff capped at 4 s
  with cached negatives.
- **Docs (rev 14):** README rebuilt (single EN+IT copy — an old bad splice had
  duplicated the whole file; missing `assisted_ingestion.png` /
  `insights_dashboard.png` captured from the live UI offscreen) and this guide
  refreshed to rev-13 code.
- **Counts at rev 14:** suite 681/12/4 · pins 103+9+4 · gates 61/0 · 62/0 ·
  anchors OK · harness phases A–H PASS · deep proof 270/270, 27 pages.

## 15. Standing user constraints (never violate)

1. Dev = code-only + synthetic tests; user-supplied run batches are sanctioned
   for review reads only.
2. Evergreen/pipeline/open-application postings stay **ACCEPTED**.
3. Keep the app simple; **GPU/hardware acceleration stays out**.
4. Deliverable = the GitHub repository. Release installers come from the root build
   scripts; version single-source = `pyproject.toml`.
5. Coverage scope: "quick-plus" (P1/P2/P3/P5/P6/P7/P8); SuccessFactors adapter
   deferred to a later round unless the user reopens it.
6. Board/agency seed rows merge into `career_jobs.csv` with a source marker —
   never a separate `_recruiter.csv`.
7. Scan speed matters, but politeness/human-like delays are intentional.
8. "Failed to scrap" means **zero-job portals** — prioritize empty→rows over
   cosmetic work.
9. **No portal-specific hardcoded patches** (2026-10-11): fixes must be
   universal failure-class mechanisms over markup structures, proven on
   structure pins — never host-name rules.
10. Process (2026-10-11, amended 2026-10-17): reproduce from run artifacts →
    failing pin first → fix → replay on real rows → **live-run before
    shipping** → gates → commit (changelog entry) → honest proven-vs-open
    report. Screenshot protocol: after each scan review, list missing/erroring
    companies; the user supplies browser screenshots (URL bar + count + job card)
    as browser-truth.
