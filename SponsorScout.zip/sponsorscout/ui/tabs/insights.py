"""Insights tab: aggregated distribution of categories, skills, domains, and sponsorship.

Draws vibrant, colourful charts with native QPainter:
- DonutPieChart with clear interactive legend, slice percentages, and hover tooltips.
- Dynamic HorizontalBarChart with gradients, counts, and scrollable container for ALL data points.
- Table with distinct colour-coded badges for Visa / Relocation statuses.
- Country & source filter controls and on-demand database re-analysis.
"""
from __future__ import annotations

import logging
import math
from typing import Any

from PySide6.QtCore import Qt, QRect, QRectF, QPointF, QSize, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QBrush, QLinearGradient
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QToolTip,
    QVBoxLayout,
    QWidget,
)

from sponsorscout.i18n import _

logger = logging.getLogger(__name__)

COLOR_PALETTE = [
    ("#3B82F6", "#1D4ED8"),  # Blue
    ("#10B981", "#047857"),  # Emerald
    ("#8B5CF6", "#6D28D9"),  # Purple
    ("#F59E0B", "#B45309"),  # Amber
    ("#EC4899", "#BE185D"),  # Pink
    ("#06B6D4", "#0E7490"),  # Cyan
    ("#F97316", "#C2410C"),  # Orange
    ("#6366F1", "#4338CA"),  # Indigo
    ("#14B8A6", "#0F766E"),  # Teal
    ("#84CC16", "#4D7C0F"),  # Lime
    ("#E11D48", "#9F1239"),  # Rose
    ("#64748B", "#334155"),  # Slate
]


class DonutPieChart(QWidget):
    """Custom Donut / Pie chart with interactive filtering, side legend, and hover tooltips."""

    slice_clicked = Signal(str)  # emits the clicked category/domain label (or empty string to clear)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.items: list[tuple[str, int]] = []
        self.selected_label: str = ""
        self.setMinimumHeight(240)
        self.setMinimumWidth(320)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.setMouseTracking(True)
        self._slices: list[dict] = []
        self._legend_rects: list[tuple[QRect, str]] = []

    def set_data(self, items: list[tuple[str, int]], selected_label: str = ""):
        self.items = items or []
        self.selected_label = selected_label or ""
        self._compute_slices()
        self.update()

    def set_selected(self, label: str):
        self.selected_label = label or ""
        self.update()

    def _compute_slices(self):
        self._slices = []
        if not self.items:
            return
        total = sum(cnt for _, cnt in self.items) or 1
        top_items = self.items[:8]
        other_cnt = sum(cnt for _, cnt in self.items[8:])
        display_items = list(top_items)
        if other_cnt > 0:
            display_items.append((_("Other"), other_cnt))

        current_angle = 90.0
        for idx, (label, count) in enumerate(display_items):
            pct = (count / total) * 100.0
            span = (count / total) * 360.0
            color_hex = COLOR_PALETTE[idx % len(COLOR_PALETTE)][0]
            self._slices.append({
                "label": label,
                "count": count,
                "pct": pct,
                "start_angle": current_angle,
                "span_angle": span,
                "color": color_hex,
            })
            current_angle -= span

    def _get_slice_at(self, pos) -> str | None:
        """Return the label of the slice at position pos, or '__center__' if donut hole clicked."""
        w, h = self.width(), self.height()
        pie_size = min(h - 30, int(w * 0.42))
        cx = 20.0 + pie_size / 2.0
        cy = h / 2.0
        dx = pos.x() - cx
        dy = -(pos.y() - cy)
        dist = math.hypot(dx, dy)
        outer_r = pie_size / 2.0
        inner_r = outer_r * 0.52

        if dist < inner_r:
            return "__center__"

        if inner_r <= dist <= outer_r:
            angle = math.degrees(math.atan2(dy, dx))
            if angle < 0:
                angle += 360.0
            for sl in self._slices:
                s_ang = sl["start_angle"] % 360.0
                e_ang = (sl["start_angle"] - sl["span_angle"]) % 360.0
                matched = False
                if s_ang >= e_ang:
                    matched = (e_ang <= angle <= s_ang)
                else:
                    matched = (angle <= s_ang or angle >= e_ang)
                if matched:
                    return sl["label"]

        # Check legend clicks
        for rect, label in self._legend_rects:
            if rect.contains(int(pos.x()), int(pos.y())):
                return label

        return None

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            label = self._get_slice_at(event.position())
            if label == "__center__":
                # Center click clears any active filter
                self.slice_clicked.emit("")
            elif label:
                if self.selected_label == label:
                    # Toggle off
                    self.slice_clicked.emit("")
                else:
                    self.slice_clicked.emit(label)

    def mouseMoveEvent(self, event):
        if not self._slices:
            return
        label = self._get_slice_at(event.position())
        if label == "__center__":
            tip = _("Click center to clear filter") if self.selected_label else _("Total Jobs")
            QToolTip.showText(event.globalPosition().toPoint(), tip, self)
            self.setCursor(Qt.PointingHandCursor)
            return

        if label:
            sl = next((s for s in self._slices if s["label"] == label), None)
            if sl:
                action = _("Click to unfilter") if self.selected_label == label else _("Click to filter dashboard")
                tip = f"{sl['label']}: {sl['count']} ({sl['pct']:.1f}%)\n{action}"
                QToolTip.showText(event.globalPosition().toPoint(), tip, self)
                self.setCursor(Qt.PointingHandCursor)
                return

        self.setCursor(Qt.ArrowCursor)
        QToolTip.hideText()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        if not self.items:
            painter.setPen(QColor("#9CA3AF"))
            painter.drawText(self.rect(), int(Qt.AlignCenter), _("No data available"))
            painter.end()
            return

        total = sum(cnt for _, cnt in self.items) or 1
        w, h = self.width(), self.height()

        pie_size = min(h - 30, int(w * 0.42))
        pie_rect = QRectF(20.0, (h - pie_size) / 2.0, float(pie_size), float(pie_size))

        if not self._slices:
            self._compute_slices()

        for sl in self._slices:
            s_angle = int(sl["start_angle"] * 16)
            s_span = -int(sl["span_angle"] * 16)
            is_sel = (self.selected_label == sl["label"])

            # If something is selected, fade out unselected slices slightly
            col = QColor(sl["color"])
            if self.selected_label and not is_sel:
                col.setAlpha(90)
            else:
                col.setAlpha(255)

            painter.setBrush(QBrush(col))
            if is_sel:
                painter.setPen(QPen(QColor("#1E293B"), 3))
            else:
                painter.setPen(QPen(QColor("#FFFFFF"), 2))

            painter.drawPie(pie_rect, s_angle, s_span)

        hole_size = pie_size * 0.52
        hole_rect = QRectF(
            pie_rect.center().x() - hole_size / 2.0,
            pie_rect.center().y() - hole_size / 2.0,
            hole_size,
            hole_size,
        )
        painter.setBrush(QBrush(QColor("#FFFFFF")))
        painter.setPen(QPen(QColor("#E5E7EB"), 1))
        painter.drawEllipse(hole_rect)

        painter.setPen(QColor("#1F2937"))
        f_center = painter.font()
        f_center.setPointSize(10)
        f_center.setBold(True)
        painter.setFont(f_center)
        if self.selected_label:
            c_text = f"{total}\n" + _("Filtered")
        else:
            c_text = f"{total}\n" + _("Jobs")
        painter.drawText(hole_rect.toRect(), int(Qt.AlignCenter), c_text)

        legend_x = int(pie_rect.right() + 24)
        legend_y = 16
        legend_w = max(100, w - legend_x - 12)
        item_h = 22

        f_leg = painter.font()
        f_leg.setPointSize(8)
        f_leg.setBold(False)
        painter.setFont(f_leg)

        self._legend_rects = []
        for sl in self._slices:
            is_sel = (self.selected_label == sl["label"])
            col = QColor(sl["color"])
            if self.selected_label and not is_sel:
                col.setAlpha(100)

            item_rect = QRect(legend_x, legend_y, legend_w, item_h)
            self._legend_rects.append((item_rect, sl["label"]))

            painter.setBrush(QBrush(col))
            painter.setPen(Qt.NoPen)
            painter.drawRoundedRect(QRect(legend_x, legend_y + 4, 12, 12), 3, 3)

            text = f"{sl['label']} ({sl['pct']:.1f}%)"
            elided = painter.fontMetrics().elidedText(text, Qt.ElideRight, legend_w - 20)
            
            if is_sel:
                painter.setPen(QColor("#1D4ED8"))
                f_bold = painter.font()
                f_bold.setBold(True)
                painter.setFont(f_bold)
            else:
                painter.setPen(QColor("#374151") if not self.selected_label else QColor("#9CA3AF"))
                f_plain = painter.font()
                f_plain.setBold(False)
                painter.setFont(f_plain)

            painter.drawText(QRect(legend_x + 18, legend_y, legend_w - 20, item_h), int(Qt.AlignVCenter | Qt.AlignLeft), elided)

            legend_y += item_h

        painter.end()


class ScrollableBarChart(QWidget):
    """Horizontal bar chart housed in a scroll area to present EVERY data point without cap."""

    def __init__(self, color_pair: tuple[str, str] = None, parent=None):
        super().__init__(parent)
        self.color_pair = color_pair
        self.items: list[tuple[str, int]] = []

    def set_data(self, items: list[tuple[str, int]]):
        self.items = items or []
        needed_height = max(160, len(self.items) * 26 + 30)
        self.setFixedHeight(needed_height)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        if not self.items:
            painter.setPen(QColor("#9CA3AF"))
            painter.drawText(self.rect(), int(Qt.AlignCenter), _("No data available"))
            painter.end()
            return

        w = self.width()
        max_val = max((cnt for _, cnt in self.items), default=1) or 1
        label_col_w = min(220, int(w * 0.38))
        chart_w = max(100, w - label_col_w - 70)
        y = 10
        bar_h = 16

        for idx, (label, count) in enumerate(self.items):
            start_hex, end_hex = self.color_pair if self.color_pair else COLOR_PALETTE[idx % len(COLOR_PALETTE)]

            painter.setPen(QColor("#1F2937"))
            font = painter.font()
            font.setPointSize(9)
            font.setBold(False)
            painter.setFont(font)
            label_rect = QRect(8, y - 2, label_col_w - 14, bar_h + 4)
            elided = painter.fontMetrics().elidedText(label, Qt.ElideRight, label_col_w - 14)
            painter.drawText(label_rect, int(Qt.AlignVCenter | Qt.AlignLeft), elided)

            bw = max(4, int((count / max_val) * chart_w))
            bar_x = label_col_w
            bar_rect = QRect(bar_x, y, bw, bar_h)

            grad = QLinearGradient(bar_x, y, bar_x + bw, y)
            grad.setColorAt(0.0, QColor(start_hex))
            grad.setColorAt(1.0, QColor(end_hex))
            painter.setBrush(QBrush(grad))
            painter.setPen(Qt.NoPen)
            painter.drawRoundedRect(bar_rect, 4, 4)

            painter.setPen(QColor("#4B5563"))
            font.setPointSize(8)
            font.setBold(True)
            painter.setFont(font)
            cnt_rect = QRect(bar_x + bw + 8, y - 2, 50, bar_h + 4)
            painter.drawText(cnt_rect, int(Qt.AlignVCenter | Qt.AlignLeft), str(count))

            y += 26

        painter.end()


class InsightsTab(QWidget):
    """Seventh tab: Visual market intelligence and granular insights across all scanned jobs."""

    def __init__(self, db_path: str, parent=None):
        super().__init__(parent)
        self.db_path = db_path

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(10)

        # Filters Bar
        header_box = QGroupBox(_("Filters & Coverage"))
        h_layout = QHBoxLayout(header_box)
        h_layout.setContentsMargins(10, 10, 10, 10)
        h_layout.setSpacing(12)

        # Country Filter
        h_layout.addWidget(QLabel(_("Country:")))
        self.country_combo = QComboBox()
        self.country_combo.currentIndexChanged.connect(self.refresh)
        h_layout.addWidget(self.country_combo)

        # Source Type Filter
        h_layout.addWidget(QLabel(_("Source:")))
        self.source_combo = QComboBox()
        self.source_combo.addItem(_("All Sources"), "")
        self.source_combo.addItem(_("Direct Employers Only"), "direct")
        self.source_combo.addItem(_("Aggregators / Agencies Only"), "recruiter")
        self.source_combo.currentIndexChanged.connect(self.refresh)
        h_layout.addWidget(self.source_combo)

        # Refresh button
        self.refresh_btn = QPushButton(_("Refresh"))
        self.refresh_btn.clicked.connect(self.refresh)
        h_layout.addWidget(self.refresh_btn)

        # Re-Analyse Button (British English)
        self.reanalyze_btn = QPushButton(_("Re-Analyse Database Skills"))
        self.reanalyze_btn.setToolTip(_("Extract updated skills and granular categories across all existing jobs in the database"))
        self.reanalyze_btn.clicked.connect(self._reanalyze_database)
        h_layout.addWidget(self.reanalyze_btn)

        # Coverage Banner
        self.coverage_label = QLabel(_("Coverage: --"))
        self.coverage_label.setStyleSheet("color: #1F2937; font-weight: bold; background: #F3F4F6; padding: 4px 10px; border-radius: 4px;")
        h_layout.addStretch(1)
        h_layout.addWidget(self.coverage_label)

        root.addWidget(header_box)

        # Main Scrollable View with dedicated styling and smooth vertical scrolling
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        content_widget = QWidget()
        content_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.grid = QVBoxLayout(content_widget)
        self.grid.setContentsMargins(4, 4, 4, 16)
        self.grid.setSpacing(16)
        self.scroll.setWidget(content_widget)
        root.addWidget(self.scroll, 1)

        # Row 1: Donut Pie Charts (High Level Category & Domain Breakdown)
        row_pie = QHBoxLayout()
        row_pie.setSpacing(14)

        # Active cross-filter status banner
        self.active_pie_filter: tuple[str, str] = ("", "")  # (type: "category"|"domain", value: str)

        self.pie_cat_box = QGroupBox(_("Job Role / Category Distribution (Functional Profession)"))
        self.pie_cat_box.setToolTip(_("Click any slice or legend item to filter the dashboard by this category"))
        pie_cat_lay = QVBoxLayout(self.pie_cat_box)
        self.pie_cat_chart = DonutPieChart()
        self.pie_cat_chart.slice_clicked.connect(lambda cat: self._on_pie_slice_clicked("category", cat))
        pie_cat_lay.addWidget(self.pie_cat_chart)
        row_pie.addWidget(self.pie_cat_box, 1)

        self.pie_dom_box = QGroupBox(_("Employer Industry Domain (Hiring Company Sector)"))
        self.pie_dom_box.setToolTip(_("Click any slice or legend item to filter the dashboard by this industry sector"))
        pie_dom_lay = QVBoxLayout(self.pie_dom_box)
        self.pie_dom_chart = DonutPieChart()
        self.pie_dom_chart.slice_clicked.connect(lambda dom: self._on_pie_slice_clicked("domain", dom))
        pie_dom_lay.addWidget(self.pie_dom_chart)
        row_pie.addWidget(self.pie_dom_box, 1)

        self.grid.addLayout(row_pie)

        # Interactive Filter Indicator / Reset Bar
        self.filter_indicator_widget = QWidget()
        filter_ind_lay = QHBoxLayout(self.filter_indicator_widget)
        filter_ind_lay.setContentsMargins(4, 0, 4, 0)
        self.filter_indicator_lbl = QLabel("")
        self.filter_indicator_lbl.setStyleSheet(
            "background-color: #EFF6FF; color: #1D4ED8; font-weight: bold; "
            "padding: 5px 12px; border: 1px solid #BFDBFE; border-radius: 4px;"
        )
        self.clear_pie_filter_btn = QPushButton(_("Clear Filter (Show All)"))
        self.clear_pie_filter_btn.setStyleSheet(
            "background-color: #FFFFFF; color: #DC2626; border: 1px solid #FCA5A5; "
            "padding: 4px 10px; border-radius: 4px; font-weight: bold;"
        )
        self.clear_pie_filter_btn.clicked.connect(self._clear_pie_filter)
        filter_ind_lay.addWidget(self.filter_indicator_lbl)
        filter_ind_lay.addWidget(self.clear_pie_filter_btn)
        filter_ind_lay.addStretch(1)
        self.filter_indicator_widget.setVisible(False)
        self.grid.addWidget(self.filter_indicator_widget)

                # Row 2: Granular Categories & Distinct Side-by-Side Skills Visuals
        row_bars = QHBoxLayout()
        row_bars.setSpacing(12)

        # 1. Left: Granular Categories
        self.cat_box = QGroupBox(_("Jobs by Granular Category (All Categories)"))
        cat_vbox = QVBoxLayout(self.cat_box)
        cat_scroll = QScrollArea()
        cat_scroll.setWidgetResizable(True)
        cat_scroll.setFixedHeight(230)
        self.cat_chart = ScrollableBarChart()
        cat_scroll.setWidget(self.cat_chart)
        cat_vbox.addWidget(cat_scroll)
        row_bars.addWidget(self.cat_box, 1)

        # 2. Middle-Right: Dedicated Technical Skills Visual
        self.tech_skill_box = QGroupBox(_("In-Demand Technical Skills & Tools"))
        tech_vbox = QVBoxLayout(self.tech_skill_box)
        tech_scroll = QScrollArea()
        tech_scroll.setWidgetResizable(True)
        tech_scroll.setFixedHeight(230)
        self.tech_skill_chart = ScrollableBarChart(color_pair=("#3B82F6", "#1D4ED8"))
        tech_scroll.setWidget(self.tech_skill_chart)
        tech_vbox.addWidget(tech_scroll)
        row_bars.addWidget(self.tech_skill_box, 1)

        # 3. Far-Right: Dedicated Soft & Professional Skills Visual
        self.soft_skill_box = QGroupBox(_("In-Demand Soft & Professional Skills"))
        soft_vbox = QVBoxLayout(self.soft_skill_box)
        soft_scroll = QScrollArea()
        soft_scroll.setWidgetResizable(True)
        soft_scroll.setFixedHeight(230)
        self.soft_skill_chart = ScrollableBarChart(color_pair=("#10B981", "#047857"))
        soft_scroll.setWidget(self.soft_skill_chart)
        soft_vbox.addWidget(soft_scroll)
        row_bars.addWidget(self.soft_skill_box, 1)

        # Keep self.skill_chart alias pointing to tech_skill_chart for backwards compatibility
        self.skill_chart = self.tech_skill_chart
        self.skill_box = self.tech_skill_box

        self.grid.addLayout(row_bars)

        # Row 3: Sponsorship Breakdown Table
        self.spon_box = QGroupBox(_("Sponsorship by Category"))
        spon_vbox = QVBoxLayout(self.spon_box)
        self.spon_table = QTableWidget(0, 5)
        self.spon_table.setHorizontalHeaderLabels([
            _("Category"), _("Total"), _("Visa Yes"), _("Visa ?"), _("Reloc Yes")
        ])
        self.spon_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.spon_table.verticalHeader().setVisible(False)
        self.spon_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.spon_table.setAlternatingRowColors(True)
        self.spon_table.setMinimumHeight(260)
        self.spon_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.MinimumExpanding)
        spon_vbox.addWidget(self.spon_table)
        self.grid.addWidget(self.spon_box)

        # Disclaimer
        note = QLabel(_("* Insights reflect scanned job portals in SponsorScout's database, not the entire employment market."))
        note.setStyleSheet("color: #6B7280; font-size: 11px; font-style: italic;")
        self.grid.addWidget(note)

        self._populate_countries()
        self.refresh()

    def _populate_countries(self):
        try:
            from sponsorscout.db.database import get_distinct_job_countries
            countries = get_distinct_job_countries(self.db_path)
            cur = self.country_combo.currentText()
            self.country_combo.blockSignals(True)
            self.country_combo.clear()
            self.country_combo.addItem(_("All Countries"))
            for c in countries:
                if c:
                    self.country_combo.addItem(c)
            # Restore selection if possible
            idx = self.country_combo.findText(cur)
            if idx >= 0:
                self.country_combo.setCurrentIndex(idx)
            else:
                self.country_combo.setCurrentIndex(0)
            self.country_combo.blockSignals(False)
        except Exception:
            pass

    def _reanalyze_database(self):
        """Execute on-demand backfill/re-indexing of categories, domains, and skills on a background thread."""
        from PySide6.QtCore import QThread, Signal
        from PySide6.QtWidgets import QProgressDialog

        self.reanalyze_btn.setEnabled(False)
        self.reanalyze_btn.setText(_("Analysing Database..."))

        progress = QProgressDialog(_("Re-analysing database skills & categories..."), None, 0, 0, self)
        progress.setWindowTitle(_("Processing Insights"))
        progress.setWindowModality(Qt.WindowModal)
        progress.setCancelButton(None)
        progress.show()

        class ReanalyzeWorker(QThread):
            finished_signal = Signal(int, str)

            def __init__(self, db_path):
                super().__init__()
                self.db_path = db_path

            def run(self):
                try:
                    from sponsorscout.insights import queries
                    count = queries.backfill_existing_job_terms(self.db_path, force_all=True)
                    self.finished_signal.emit(count, "")
                except Exception as e:
                    self.finished_signal.emit(0, str(e))

        self._reanalyze_worker = ReanalyzeWorker(self.db_path)

        def _on_done(count, err):
            progress.close()
            self.reanalyze_btn.setEnabled(True)
            self.reanalyze_btn.setText(_("Re-Analyse Database Skills"))
            if err:
                QMessageBox.warning(self, _("Re-Analysis Failed"), err)
            else:
                QMessageBox.information(
                    self, _("Re-Analysis Complete"),
                    _("Successfully re-analysed %d jobs with updated granular categories and skills!") % count
                )
                self._populate_countries()
                self.refresh()

        self._reanalyze_worker.finished_signal.connect(_on_done)
        self._reanalyze_worker.start()

    def _on_pie_slice_clicked(self, filter_type: str, label: str):
        """Handle user clicking a slice or legend item in Category or Domain pie charts."""
        if not label or (self.active_pie_filter[0] == filter_type and self.active_pie_filter[1] == label):
            self.active_pie_filter = ("", "")
        else:
            self.active_pie_filter = (filter_type, label)
        self.refresh()

    def _clear_pie_filter(self):
        self.active_pie_filter = ("", "")
        self.refresh()

    def refresh(self):
        """Reload all insights according to current filters."""
        from sponsorscout.insights import queries

        # Auto-index terms if database contains jobs but zero skills have been extracted yet
        try:
            cov_check = queries.get_insights_coverage(self.db_path)
            if cov_check.get("total_jobs", 0) > 0 and cov_check.get("jobs_with_skills", 0) == 0:
                queries.backfill_existing_job_terms(self.db_path, force_all=True)
                self._populate_countries()
        except Exception as ex:
            logger.error("Auto backfill check failed: %s", ex, exc_info=True)

        country = self.country_combo.currentText()
        if country == _("All Countries") or not country:
            country = None

        source_sub = self.source_combo.currentData() or None

        # Cross-filter values from pie charts
        f_type, f_val = self.active_pie_filter
        cat_filter = f_val if f_type == "category" else ""
        dom_filter = f_val if f_type == "domain" else ""

        # Update Filter Indicator Bar
        if f_val:
            type_name = _("Category") if f_type == "category" else _("Employer Domain")
            self.filter_indicator_lbl.setText(_("Filtered by %s: %s") % (type_name, f_val))
            self.filter_indicator_widget.setVisible(True)
        else:
            self.filter_indicator_widget.setVisible(False)

        # 1. Coverage
        try:
            cov = queries.get_insights_coverage(
                self.db_path, country=country, source_subtype=source_sub, category=cat_filter, domain=dom_filter
            )
            tot = cov["total_jobs"]
            cat_pct = (cov["categorized_jobs"] / tot * 100) if tot else 0.0
            skl_pct = (cov["jobs_with_skills"] / tot * 100) if tot else 0.0
            self.coverage_label.setText(
                _("Categorised: %d / %d (%.1f%%) | With Skills: %d (%.1f%%)")
                % (
                    cov["categorized_jobs"],
                    tot,
                    cat_pct,
                    cov["jobs_with_skills"],
                    skl_pct,
                )
            )
        except Exception as e:
            logger.debug("Error getting coverage: %s", e)

        # 2. Categories & Category Pie Chart
        try:
            cats = queries.get_jobs_by_category(
                self.db_path, country=country, source_subtype=source_sub, domain=dom_filter
            )
            self.cat_chart.set_data(cats)
            self.pie_cat_chart.set_data(cats, selected_label=cat_filter)
        except Exception as e:
            logger.debug("Error getting categories: %s", e)

        # 3. Top Skills (Distinct Technical & Soft Visuals, filtered by selected category/domain)
        try:
            skills_dict = queries.get_segregated_skills(
                self.db_path, country=country, source_subtype=source_sub, category=cat_filter, domain=dom_filter
            )
            self.tech_skill_chart.set_data(skills_dict.get("technical", []))
            self.soft_skill_chart.set_data(skills_dict.get("soft", []))
        except Exception as e:
            logger.debug("Error getting skills: %s", e)

        # 4. Employer Domains & Domain Pie Chart
        try:
            domains = queries.get_jobs_by_domain(
                self.db_path, country=country, source_subtype=source_sub, category=cat_filter
            )
            self.pie_dom_chart.set_data(domains, selected_label=dom_filter)
        except Exception as e:
            logger.debug("Error getting domains: %s", e)

        # 5. Sponsorship Table (filtered by selected category/domain)
        try:
            spon_data = queries.get_sponsorship_by_category(
                self.db_path, country=country, source_subtype=source_sub, category=cat_filter, domain=dom_filter
            )
            self.spon_table.setRowCount(len(spon_data))
            for i, row in enumerate(spon_data):
                item_cat = QTableWidgetItem(str(row["category"]))
                f_cat = item_cat.font()
                f_cat.setBold(True)
                item_cat.setFont(f_cat)

                item_tot = QTableWidgetItem(str(row["total"]))
                item_tot.setTextAlignment(int(Qt.AlignCenter))

                item_vy = QTableWidgetItem(str(row["visa_yes"]))
                item_vy.setTextAlignment(int(Qt.AlignCenter))
                item_vy.setForeground(QColor("#059669"))  # emerald

                item_vu = QTableWidgetItem(str(row["visa_unk"]))
                item_vu.setTextAlignment(int(Qt.AlignCenter))
                item_vu.setForeground(QColor("#D97706"))  # amber

                item_ry = QTableWidgetItem(str(row["reloc_yes"]))
                item_ry.setTextAlignment(int(Qt.AlignCenter))
                item_ry.setForeground(QColor("#2563EB"))  # blue

                self.spon_table.setItem(i, 0, item_cat)
                self.spon_table.setItem(i, 1, item_tot)
                self.spon_table.setItem(i, 2, item_vy)
                self.spon_table.setItem(i, 3, item_vu)
                self.spon_table.setItem(i, 4, item_ry)

            # Dynamically size spon_table to show rows cleanly
            row_count = len(spon_data)
            header_h = self.spon_table.horizontalHeader().height() or 30
            row_h = self.spon_table.rowHeight(0) if row_count > 0 else 28
            calc_height = header_h + (row_count * row_h) + 20
            self.spon_table.setFixedHeight(max(260, min(550, calc_height)))
        except Exception as e:
            logger.debug("Error getting sponsorship table: %s", e)
