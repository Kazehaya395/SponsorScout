"""Shared constants and concurrency-budget helpers across scanner phases.

The scanner runs in two phases (ATS API boards first, then career portals).
To avoid blowing past machine memory or locking up low-end laptops, this module
adapts concurrency to the host's actual cores and available RAM.
"""

from __future__ import annotations

import logging
import os
import ssl
import threading
import time

logger = logging.getLogger(__name__)

# Absolute floor: pretend the machine has at least this much available RAM so
# temporary spikes in another app cannot permanently starve the scan.
_MIN_USABLE_RAM = 2.0 * (1024 ** 3)  # 2 GiB

# Low-memory machine cutoff (laptops with 8 GiB or less):
_LOW_MEMORY_RAM = 7.5 * (1024 ** 3)


def host_workers_limits() -> tuple[int, float, float]:
    """Return (cpu_count, total_ram_bytes, available_ram_bytes)."""
    cpu = os.cpu_count() or 2
    total_ram = 8.0 * (1024 ** 3)
    avail_ram = 6.0 * (1024 ** 3)

    try:
        import psutil
        vm = psutil.virtual_memory()
        return cpu, float(vm.total), float(vm.available)
    except Exception:
        pass

    try:
        import ctypes
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]
        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
            return cpu, float(stat.ullTotalPhys), float(stat.ullAvailPhys)
    except Exception:
        pass

    try:
        if os.path.exists("/proc/meminfo"):
            mem = {}
            with open("/proc/meminfo") as f:
                for line in f:
                    parts = line.split(":")
                    if len(parts) == 2:
                        key = parts[0].strip()
                        val = parts[1].strip().split()[0]
                        mem[key] = int(val) * 1024
            if "MemTotal" in mem and "MemAvailable" in mem:
                return cpu, float(mem["MemTotal"]), float(mem["MemAvailable"])
    except Exception:
        pass

    return cpu, total_ram, avail_ram


def recommended_workers(kind: str = "browser", requested: int | None = None) -> int:
    """Concurrency level suited to *this* machine.

    Adaptive scaling:
    - If SPONSORSCOUT_HIGH_PERFORMANCE / SPONSORSCOUT_TURBO is enabled, leverages
      the full power of available CPU cores and RAM with higher browser and HTTP workers.
    - Honors explicit SPONSORSCOUT_MAX_WORKERS and SPONSORSCOUT_HTTP_WORKERS.
    """
    turbo = os.environ.get("SPONSORSCOUT_HIGH_PERFORMANCE") in ("1", "true", "True") or \
            os.environ.get("SPONSORSCOUT_TURBO") in ("1", "true", "True")

    raw_env = os.environ.get("SPONSORSCOUT_MAX_WORKERS" if kind == "browser" else "SPONSORSCOUT_HTTP_WORKERS")
    if raw_env:
        try:
            val = int(raw_env.strip())
            if val >= 1:
                return min(val, 16 if kind == "browser" else 32)
        except (ValueError, TypeError):
            pass

    cpu, ram_total, ram_avail = host_workers_limits()
    ram = max(ram_avail, _MIN_USABLE_RAM)

    if turbo:
        # High-performance multi-threading mode
        if kind == "http":
            return max(8, min(cpu * 4, 32))
        else:
            # Browser concurrency: scale dynamically with CPU cores and RAM
            # Each headless Chromium context uses ~200-350 MB RAM
            max_by_ram = max(2, int(ram / (400 * 1024 * 1024)))
            max_by_cpu = max(2, min(cpu, 12))
            return min(max_by_cpu, max_by_ram, 12)

    # Standard adaptive mode
    if kind == "http":
        if ram < 4.0 * (1024 ** 3):
            n = 4
        else:
            n = max(4, min(cpu * 4, 16))
    else:
        # browser contexts
        if ram < 4.0 * (1024 ** 3):
            n = 1
        elif cpu >= 4 and ram >= 8.0 * (1024 ** 3):
            n = 3
        else:
            n = 2

    if requested is not None:
        try:
            n = max(1, min(int(requested), n))
        except (TypeError, ValueError):
            pass
    return n


BROWSER_ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--disable-background-networking",
    "--disable-background-timer-throttling",
    "--disable-backgrounding-occluded-windows",
    "--disable-breakpad",
    "--disable-component-extensions-with-background-pages",
    "--disable-default-apps",
    "--disable-dev-shm-usage",
    "--disable-extensions",
    "--disable-features=Translate,BackForwardCache,AcceptCHFrame,MediaRouter,OptimizationHints",
    "--disable-ipc-flooding-protection",
    "--disable-renderer-backgrounding",
    "--blink-settings=imagesEnabled=false",
    "--mute-audio",
    "--no-default-browser-check",
    "--no-first-run",
    "--no-pings",
    "--no-sandbox",
]

LOW_RESOURCE_BROWSER_ARGS = list(BROWSER_ARGS)


class ScanCancelled(Exception):
    """Raised when cooperative cancellation interrupts a scan worker."""
    pass


def check_control(cancel_event: threading.Event | None,
                  pause_event: threading.Event | None,
                  poll_sec: float = 0.25) -> bool:
    """Cooperative cancellation and pause checkpoint for scanner loops.

    Returns True if cancelled (caller should exit immediately).
    Blocks if paused until resumed or cancelled.
    """
    if cancel_event is not None and cancel_event.is_set():
        return True
    if pause_event is not None and pause_event.is_set():
        while pause_event.is_set():
            if cancel_event is not None and cancel_event.is_set():
                return True
            time.sleep(poll_sec)
    return bool(cancel_event is not None and cancel_event.is_set())


def check_cancelled(cancel_event: threading.Event | None):
    """Raise ScanCancelled if cancel_event is set."""
    if cancel_event is not None and cancel_event.is_set():
        raise ScanCancelled("Scan cancelled by user")


def sleep_interruptible(seconds: float, cancel_event: threading.Event | None = None,
                        pause_event: threading.Event | None = None, step: float = 0.05) -> bool:
    """Sleep for ``seconds`` while checking cancellation and pause events.

    Returns True if slept completely without cancellation.
    Returns False if cancelled.
    """
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if check_control(cancel_event, pause_event, poll_sec=step):
            return False
        time.sleep(min(step, max(0.005, end - time.monotonic())))
    return True


def tls_context():
    """Create a standard SSLContext for HTTPS requests."""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def workday_spaced_location(raw: str) -> str | None:
    """Normalize Workday location codes like 'IT - Venegono Superiore' -> 'Venegono Superiore, IT'
    or 'GB - 12 High Street' -> 'GB'. Returns None if raw does not match code format.
    """
    if not raw or not isinstance(raw, str):
        return None
    s = raw.strip()
    # Match patterns like: "IT - Venegono Superiore", "GB - Yeovil - Lysander Rd", "NLD - Alphen Aan Den Rijn"
    parts = [p.strip() for p in s.split(" - ") if p.strip()]
    if len(parts) >= 2:
        code = parts[0]
        # Country code: 2-3 uppercase letters
        if (len(code) in (2, 3)) and code.isalpha() and code.isupper():
            # Check remaining parts for city/address
            rest = parts[1:]
            # If second part starts with digits like "12 High Street", return country only
            if rest and rest[0] and rest[0][0].isdigit():
                return code
            # Clean off company suffixes like "S.A." or trailing address segments
            city = rest[0]
            if city.endswith(" S.A."):
                city = city[:-5].strip()
            return f"{city}, {code}"
    return None
