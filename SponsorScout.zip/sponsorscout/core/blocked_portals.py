"""Automated and assisted ingestion pipeline for bot-blocked portals.

Provides full browser crawling, human-in-the-loop CAPTCHA solving,
and multi-page vacancy harvesting across all direct employers and aggregators.
"""

from __future__ import annotations

import logging
import os
import re
import sys
import time
import webbrowser
from typing import Any
from urllib.parse import urljoin, urlparse, parse_qs, urlencode, urlunparse

logger = logging.getLogger(__name__)

#: F-22 (2026-10-22): honest completion report of the last assisted run. The
#: UI reads this so a partial harvest can never be presented as a full one:
#: it carries the pages visited, the listings harvested and WHY the
#: pagination loop stopped.
LAST_INGESTION_REPORT: dict = {}

_LOCALE_SEGMENT_RE = re.compile(r"^[A-Za-z]{2}(?:-[A-Za-z]{2,4})?$")


def strip_locale_segment(url: str) -> str | None:
    """Return ``url`` without a leading locale path segment, else ``None``.

    Generic 404 recovery (F-25): boards that answer at ``/jobs.html`` but 404
    at ``/en/jobs.html`` — any locale, any host. Replaces the old host-name
    rewrite, which guide §15.9 forbids.
    """
    parsed = urlparse(url)
    parts = [p for p in parsed.path.split("/") if p]
    if not parts or not _LOCALE_SEGMENT_RE.match(parts[0]):
        return None
    new_path = "/" + "/".join(parts[1:]) if len(parts) > 1 else "/"
    candidate = urlunparse(parsed._replace(path=new_path))
    return candidate if candidate != url else None


_PAGING_PARAMS = ("p", "page", "offset", "start", "pagina")

#: F-38 (round 13): escalating polite cool-down steps (seconds) spent on
#: repeated refused advances over a FULL page - a bot edge rate-limit window
#: can outlast a single 15 s pause. Bounded: three pauses, 150 s total.
_COOLDOWN_STEPS_S = (15.0, 45.0, 90.0)


def paging_href_candidates(page, current_url: str, tried: set) -> list:
    """Next-page URLs the board itself links to, ascending by paging value.

    Guide §12.14: follow the page's OWN hrefs. Numbered pagers only render a
    window of slots (Robert Walters shows 1..10 plus an arrow), so once the
    window ends the exact-number click finds nothing; the board's own anchors
    still carry the reachable next values. Only same-path URLs whose paging
    parameter moves forward are returned, and anything already tried is
    skipped. No host-name rules (guide §15.9).
    """
    cur = urlparse(current_url)
    cur_q = {k: v[0] for k, v in parse_qs(cur.query).items()}
    cur_val = None
    for k in _PAGING_PARAMS:
        if k in cur_q:
            try:
                cur_val = int(cur_q[k])
            except ValueError:
                cur_val = None
            break
    out = []
    try:
        hrefs = page.eval_on_selector_all(
            "a[href]", "els => els.map(e => e.getAttribute('href'))")
    except Exception:
        return out
    for h in hrefs or []:
        if not h or h.startswith(("javascript:", "#", "mailto:")):
            continue
        u = urljoin(current_url, h)
        pu = urlparse(u)
        if (pu.netloc, pu.path) != (cur.netloc, cur.path):
            continue
        q = {k: v[0] for k, v in parse_qs(pu.query).items()}
        for k in _PAGING_PARAMS:
            if k not in q:
                continue
            try:
                val = int(q[k])
            except ValueError:
                break
            if u not in tried and (cur_val is None or val > cur_val):
                out.append((val, u))
            break
    out.sort()
    return [u for _, u in out]


def _paging_value(u: str):
    """The paging-parameter value a URL carries, or None (F-37d)."""
    q = {k: v[0] for k, v in parse_qs(urlparse(u).query).items()}
    for k in _PAGING_PARAMS:
        if k in q:
            try:
                return int(q[k])
            except ValueError:
                return None
    return None


def _page_is_challenge(page) -> bool:
    """True when the loaded document is a bot-protection interstitial."""
    try:
        content = (page.content() or "").casefold()
        title = (page.title() or "").casefold()
    except Exception:
        return False
    return (
        "challenge" in title or
        "access to this page has been denied" in title or
        "request has been blocked" in title or
        "turnstile" in content or
        "cf-chl" in content or
        "perimeterx" in content or
        "verify you are human" in content or
        "just a moment..." in title or
        "attention required! | cloudflare" in title or
        "press & hold" in content or
        "pardon our interruption" in content or
        "checking your browser" in content or
        "securing your connection" in content
    )


def _page_has_listing(page) -> bool:
    """True when the document reads as a job listing page (F-22 criteria)."""
    try:
        content = (page.content() or "").casefold()
        title = (page.title() or "").casefold()
    except Exception:
        return False
    return (
        "search results" in content or
        "suchergebnisse" in content or
        "vacatures" in content or
        "job results" in content or
        "stellenangebote" in content or
        "vacancies" in content or
        "search jobs" in title or
        "vacatures" in title or
        "stellenangebote" in title or
        "apply now" in content or
        "salary:" in content or
        "gehalt:" in content or
        "salaris:" in content or
        _jobish_anchor_count(page) >= 3
    )


def _wait_for_clearance(page, wait_s: float = 180.0) -> bool:
    """Poll until a human clears the challenge in the assisted window."""
    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline:
        try:
            if page.is_closed():
                return False
        except Exception:
            return False
        time.sleep(1.5)
        try:
            if not _page_is_challenge(page) and _page_has_listing(page):
                return True
        except Exception:
            continue
    return False


def _recover_blank_page(page, current_url: str, page_num: int,
                        wait_s: float = 180.0) -> str:
    """F-31: a load produced *no* listing content at all - classify it.

    Mid-run this is what a re-engaging bot wall or a failed render looks like
    (your round-6 run: 70 jobs, then page 8 returned nothing and the harvest
    reported "no next-page control recognised", which describes the code, not
    the board). The assisted window is interactive, so a challenge gets the
    same human-clearance wait as the first page; anything else gets one honest
    reload. Returns "cleared" | "challenge" | "blank".
    """
    if _page_is_challenge(page):
        logger.info("Bot protection re-engaged on page %d; waiting for human "
                    "clearance in the assisted window", page_num)
        if _wait_for_clearance(page, wait_s):
            try:
                page.goto(current_url, wait_until="domcontentloaded", timeout=30000)
                time.sleep(2.0)
            except Exception:
                pass
            return "cleared"
        return "challenge"
    try:
        logger.info("Page %d rendered no listing content; reloading once", page_num)
        page.reload(wait_until="domcontentloaded", timeout=30000)
        time.sleep(3.0)
    except Exception:
        return "blank"
    if _page_is_challenge(page):
        logger.info("Reload of page %d surfaced a bot challenge; waiting for "
                    "human clearance", page_num)
        if _wait_for_clearance(page, wait_s):
            try:
                page.goto(current_url, wait_until="domcontentloaded", timeout=30000)
                time.sleep(2.0)
            except Exception:
                pass
            return "cleared"
        return "challenge"
    if _page_has_listing(page):
        return "cleared"
    return "blank"


def _jobish_anchor_count(page) -> int:
    """Count listing-shaped anchors on the page.

    A bot-denial or consent shell carries at most one navigation anchor, so a
    bare ``a[href*='/jobs/']`` probe false-positives as "real job listings"
    (F-22, live-verified on a PerimeterX denial page 2026-10-22). Requiring
    several listing-shaped anchors keeps the check a universal failure class.
    """
    try:
        return len(page.query_selector_all(
            "article a[href], a[href*='/jobs/'], a[href*='/job/'], "
            "a[href*='/vacancies/']"))
    except Exception:
        return 0


def next_page_url(current_url: str, page_num: int) -> str | None:
    """Generic query-parameter paging step (F-22 / F-25).

    Increments whichever paging parameter the board already uses, preserving
    that board's indexing scheme; only *probes* ``p`` when the URL carries no
    scheme of its own. A board that ignores the synthesised parameter is
    caught by the caller's no-progress stop — never by a host-name rule.
    """
    parsed = urlparse(current_url)
    q = parse_qs(parsed.query)
    if "p" in q:
        try:
            q["p"] = [str(int(q["p"][0]) + 1)]
        except ValueError:
            q["p"] = [str(page_num)]
    elif "page" in q:
        try:
            q["page"] = [str(int(q["page"][0]) + 1)]
        except ValueError:
            q["page"] = [str(page_num + 1)]
    else:
        q["p"] = [str(page_num)]
    candidate = urlunparse(parsed._replace(query=urlencode(q, doseq=True)))
    return candidate if candidate != current_url else None


#: F-28 (2026-10-22): generic call-to-action / footer chrome that boards render
#: as anchors and that a listing harvest must never ingest as a vacancy
#: ("Create job alert", "Register your CV", "Salary Calculator", ... seen live
#: in a Robert Walters footer). Universal patterns, no host rules (guide 15.9).
_NOISE_CTA_RE = re.compile(
    r"^(create (a )?job alerts?|job alerts?|subscribe( to.*)?|register( your)? cv|"
    r"submit( your)? (cv|resume)|refer a friend|salary calculator|careers advice|"
    r"quick links|read more|more information|looking to hire\??|"
    r"looking for a job\??|save job|search jobs|view all (jobs|vacancies)|"
    r"load more|show more|cookies?( policy)?|privacy( policy)?|terms( of use)?|"
    r"imprint|contact( us)?|sitemap|newsletter|key contact|offices|our locations)"
    r"[\s!.?]*$",
    re.I)


#: F-33 (2026-10-22): URL-shape guards. A vacancy title on a chrome URL is still
#: chrome (your round-7 run: 172/172 complete but one row whose title read like a
#: job while its URL was not a job page). Generic patterns only - no host names
#: (guide §15.9).
_CHROME_PATH_RE = re.compile(
    r"/(job-alerts?|register-cv|submit-cv|upload-cv|refer-a-friend|"
    r"salary-calculator|careers-advice|quick-links|offices|our-locations|"
    r"about(-us)?|contact(-us)?|imprint|privacy|terms|sitemap|newsletter|"
    r"my-account|login|logout|register|signin|signup)(/|$|\.)", re.I)


def is_chrome_url(url: str) -> bool:
    """True when the path is portal chrome, whatever the anchor text says."""
    try:
        path = urlparse(url).path
    except Exception:
        return False
    return bool(_CHROME_PATH_RE.search(path))


_JOBISH_QUERY_KEYS = {"id", "job", "jobid", "job_id", "vacancy", "vacancyid",
                      "req", "reqid", "posting", "postingid", "slug"}


def is_listing_self_link(url: str, listing_path: str) -> bool:
    """A same-path link is paging/filter chrome - unless a job-id query says
    otherwise (some ATSes serve details at the listing path with ``?jobId=``)."""
    try:
        pu = urlparse(url)
    except Exception:
        return False
    if (pu.path.rstrip("/") or "/") != listing_path:
        return False
    keys = {k.lower() for k in parse_qs(pu.query)}
    return not (keys & _JOBISH_QUERY_KEYS)


_LOCALE_SEG_RE = re.compile(r"^[a-z]{2}(-[a-z]{2})?$", re.I)


def normalize_job_url(url: str) -> str:
    """Dedup key that treats locale variants of one job as one job.

    ``/en/jobs/slug.html`` and ``/de/jobs/slug.html`` are the same vacancy served
    in two languages; keying dedup on the raw URL ingested both. Fragment is
    dropped, trailing slash folded, host lowercased. No host-name rules.
    """
    try:
        pu = urlparse(url)
    except Exception:
        return url
    path = pu.path.rstrip("/") or "/"
    segs = [x for x in path.split("/") if x]
    if segs and _LOCALE_SEG_RE.match(segs[0]) and len(segs) > 1:
        path = "/" + "/".join(segs[1:])
    return urlunparse(("", pu.netloc.lower(), path, "", pu.query, ""))


def is_noise_cta_title(title: str) -> bool:
    """True for navigation/CTA chrome harvested by mistake as a vacancy."""
    return bool(title) and bool(_NOISE_CTA_RE.match(title.strip()))


def is_filter_or_facet_title(title: str, url: str) -> bool:
    """Detect filter tags, facet headers, and category counts (e.g. 'Rest of Ireland (19)', 'Dublin North (3)').
    
    Portals render sidebar links with count badges like `Category (N)` or `Location (N)`
    which are facets, not job vacancies.
    """
    if not title:
        return True
    t = title.strip()

    # Match patterns like: "Rest of Ireland (19)", "Dublin North (3)", "Permanent (12)", "Full-Time (45)"
    if re.search(r"\(\d+\)$", t):
        return True

    # Check for known facet keywords
    low = t.lower()
    facet_words = {
        "rest of ireland", "dublin north", "dublin south", "dublin city centre",
        "filter results", "search results", "refine search", "view all", "load more",
        "show more", "select location", "all locations", "all jobs", "cookie policy",
        "privacy policy", "terms of use", "contact us", "save job", "view vacancy",
        "read more", "apply now", "share this job", "back to search",
    }
    if low in facet_words:
        return True

    # If URL is purely a facet query (e.g. `specialization=jobsroot&location=...` without a detail job slug)
    parsed = urlparse(url)
    q = parsed.query.lower()
    if ("location=" in q or "specialization=" in q or "category=" in q or "facet=" in q) and not any(
        seg in parsed.path.lower() for seg in ("/job/", "/jobs/", "/vacancy/", "/vacancies/")
    ):
        return True

    return False


def _extract_title_from_url_slug(url: str) -> str:
    """Derive job title from clean URL slug."""
    try:
        path = urlparse(url).path.rstrip("/")
        slug = path.split("/")[-1]
        slug = re.sub(r"\.html?$", "", slug)
        slug = re.sub(r"^[0-9\-]+", "", slug)
        slug = re.sub(r"-[0-9]+$", "", slug)
        tokens = [t.capitalize() for t in slug.split("-") if t and not t.isdigit()]
        return " ".join(tokens)
    except Exception:
        return ""


def run_assisted_ingestion(url: str, seed_name: str, conn, max_pages: int = 60,
                         clear_wait_s: float = 180.0,
                         db_path: str | None = None) -> int:
    """Launch an interactive (visible) browser session for the user to solve any
    human-verification challenge, then automatically harvest all job listings
    across pagination and ingest them directly into the SQLite database.

    Works universally for ANY portal (Robert Walters, Cloudflare, Datadome, PerimeterX, etc.).
    Returns the number of jobs ingested.
    """
    from sponsorscout.core.persistence import upsert_job
    from sponsorscout.core.location_country import country_from_location
    from sponsorscout.insights.terms import extract_terms
    from sponsorscout.scanning.jd_support import (
        JDSupportDetector,
        detect_blue_card,
        VERDICT_YES,
        VERDICT_NO,
        VERDICT_UNKNOWN,
    )
    from sponsorscout.scanning.career.career_scanner import (
        ProductionScannerConfig,
        CareerPortalScanner,
        extract_experience,
        apply_support_fp_guards,
    )

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        logger.warning("Playwright not installed; cannot launch assisted browser.")
        return 0

    cfg = ProductionScannerConfig()
    scanner = CareerPortalScanner(cfg)
    detector = JDSupportDetector()
    ingested_count = 0
    new_count = 0             # F-36: rows this run actually inserted
    dup_count = 0             # F-36: re-seen rows (refreshed, not new)
    harvest_rows = []         # F-36: per-run job list for CSV parity
    last_good_count = 0       # F-35: jobs on the last complete page
    page_size_max = 0         # F-35: fullest page seen (full-page test)
    probes_left = 4           # F-35/F-37: shared end-of-board probe budget
    cooldowns_used = 0        # F-38: escalating cool-downs per run
    recover_cleared = 0       # F-35b: bounded blank-page recoveries
    probe_pending_end = False
    from datetime import datetime as _dt, timezone as _tz
    run_started = _dt.now(_tz.utc)
    seen_urls = set()
    seen_norm = set()          # F-33: locale-variant-insensitive dedup key
    listing_path = urlparse(url).path.rstrip("/") or "/"  # F-33

    with sync_playwright() as pw:
        browser = pw.chromium.launch(
            headless=False,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--start-maximized",
            ]
        )
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            no_viewport=True,
        )
        page = context.new_page()

        try:
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
        except Exception as e:
            logger.warning("Initial navigation error in assisted session: %s", e)

        # Wait for user to solve challenge if present; up to 180s
        poll_start = time.monotonic()
        challenge_seen = False
        cleared = False
        while time.monotonic() - poll_start < 180:
            try:
                if page.is_closed():
                    break
                content = (page.content() or "").casefold()
                page_title = (page.title() or "").casefold()
            except Exception:
                time.sleep(1)
                continue

            # Handle 404
            is_404 = (
                "404 not found" in page_title or
                ("not found" in page_title and "404" in content) or
                "the requested url was not found on this server" in content
            )
            if is_404:
                # Generic failure class: a locale-prefixed path that 404s while
                # the same board answers without the locale segment. No
                # host-name rules here (guide §15.9, F-25).
                fixed_url = strip_locale_segment(page.url)
                if fixed_url:
                    try:
                        page.goto(fixed_url, wait_until="domcontentloaded", timeout=45000)
                        time.sleep(2)
                        continue
                    except Exception:
                        pass

            # Detect anti-bot challenges
            is_challenge = _page_is_challenge(page)

            if is_challenge:
                challenge_seen = True
                time.sleep(1.5)
                continue

            # Real job listings present
            has_jobs = _page_has_listing(page)

            if has_jobs:
                cleared = True
                break

            time.sleep(1.0)

        if challenge_seen and not cleared:
            # F-22 / §14b: say it was a bot wall, not a quiet empty board. The
            # marker prefix is the one the post-scan blocked-portal prompt reads.
            reason = ("bot-protection challenge page; no human clearance observed "
                      "within the wait window")
            logger.info("blocked by bot protection: %s (%s)", reason, url)
            LAST_INGESTION_REPORT.update(
                url=url, ingested=0, pages_visited=0, stop_reason=reason)
            try:
                context.close()
                browser.close()
            except Exception:
                pass
            return 0

        if page.is_closed():
            logger.info("Assisted browser closed by user.")
            LAST_INGESTION_REPORT.update(
                url=url, ingested=0, pages_visited=0,
                stop_reason="browser closed by user before listings appeared")
            return 0

        # Multi-page vacancy crawler across all pagination
        page_num = 1
        current_page_url = page.url
        tried_urls = {page.url}
        recent_raws = []          # F-33b: last few listing snapshots, to catch
                                  # clamp oscillation (A,B,A,B...) as re-serves
        mis_advances = 0
        last_good_page = 0        # highest page_num that actually yielded jobs
        force_url_advance = False
        consecutive_empty_pages = 0
        pages_visited = 0
        loads = 0                 # F-34: raw browser loads, incl. retry/
                                  # oscillation phantoms; reported separately
        stop_reason = "page cap reached"

        while page_num <= max_pages and not page.is_closed():
            loads += 1
            try:
                page.wait_for_timeout(2000)
            except Exception:
                break

            # Target cards
            cards = []
            try:
                cards = page.query_selector_all(
                    "article, .job-result, [class*='job-result'], [class*='search-result'], "
                    "[class*='card-job'], [class*='job-card'], li:has(a[href*='/jobs/']), "
                    "li:has(a[href*='/vacancies/'])"
                )
            except Exception:
                cards = []

            page_jobs = []
            page_seen_raw = set()

            if cards:
                for card in cards:
                    try:
                        a_tag = card.query_selector(
                            "h2 a, h3 a, h4 a, a[class*='title'], [class*='title'] a, "
                            "a[href*='/jobs/'], a[href*='/vacancies/'], a[href*='/job/'], a"
                        )
                        if not a_tag:
                            continue
                        href = a_tag.get_attribute("href")
                        if not href:
                            continue
                        full_url = urljoin(current_page_url, href)
                        page_seen_raw.add(full_url)
                        # F-33: chrome URLs and paging/self links are never jobs;
                        # locale variants of an already-seen job are duplicates.
                        norm_url = normalize_job_url(full_url)
                        if (is_chrome_url(full_url)
                                or norm_url in seen_norm
                                or is_listing_self_link(full_url, listing_path)):
                            continue
                        if full_url in seen_urls:
                            continue

                        # Disqualify non-job portal links
                        if any(x in full_url.lower() for x in (
                            "/my-account/", "/privacy", "/terms", "/contact", "/about",
                            "personal-details", "/login", "/register", "specialization=jobsroot"
                        )):
                            continue

                        card_text = (card.inner_text() or "").strip()
                        raw_title = (a_tag.inner_text() or "").strip()
                        title = scanner.clean_job_title(raw_title)

                        # Filter out filter tags, count badges, and facet buttons
                        if is_filter_or_facet_title(title, full_url) or is_filter_or_facet_title(raw_title, full_url):
                            continue

                        if not title or title.lower() in ("search", "save job", "view vacancy", "details", "personal details", "read more", "apply"):
                            title = _extract_title_from_url_slug(full_url)

                        if (not title or len(title) < 3
                                or is_filter_or_facet_title(title, full_url)
                                or is_noise_cta_title(title)):
                            continue

                        seen_urls.add(full_url)
                        seen_norm.add(norm_url)
                        page_jobs.append((title, full_url, card_text))
                    except Exception:
                        continue
            else:
                # Strategy 2: Fallback to all detail anchors
                try:
                    anchors = page.query_selector_all("a[href]")
                except Exception:
                    break

                for a in anchors:
                    try:
                        href = a.get_attribute("href")
                        if not href:
                            continue
                        full_url = urljoin(current_page_url, href)
                        page_seen_raw.add(full_url)
                        # F-33: chrome URLs and paging/self links are never jobs;
                        # locale variants of an already-seen job are duplicates.
                        norm_url = normalize_job_url(full_url)
                        if (is_chrome_url(full_url)
                                or norm_url in seen_norm
                                or is_listing_self_link(full_url, listing_path)):
                            continue
                        if full_url in seen_urls:
                            continue

                        if any(x in full_url.lower() for x in (
                            "/my-account/", "/privacy", "/terms", "/contact", "/about",
                            "personal-details", "/login", "/register", "specialization=jobsroot"
                        )):
                            continue

                        is_detail = (
                            "/jobs/" in full_url or "/vacancies/" in full_url or
                            "/vacature/" in full_url or "/job/" in full_url or
                            "/stellenangebote/" in full_url or
                            bool(re.search(r"/\d+-[a-z0-9\-]+\.html", full_url, re.I)) or
                            bool(re.search(r"-[a-z0-9]+-\d+-\d+$", full_url, re.I))
                        )

                        if not is_detail:
                            continue

                        raw_text = (a.inner_text() or "").strip()
                        title = scanner.clean_job_title(raw_text)

                        if is_filter_or_facet_title(title, full_url) or is_filter_or_facet_title(raw_text, full_url):
                            continue

                        if not title or len(title) < 3:
                            title = _extract_title_from_url_slug(full_url)

                        if (not title or len(title) < 3
                                or is_filter_or_facet_title(title, full_url)
                                or is_noise_cta_title(title)):
                            continue

                        card_text = ""
                        try:
                            parent = a.evaluate_handle("node => node.closest('article') || node.closest('li') || node.parentElement")
                            if parent:
                                card_text = (parent.as_element().inner_text() or "").strip()
                        except Exception:
                            card_text = ""

                        seen_urls.add(full_url)
                        seen_norm.add(norm_url)
                        page_jobs.append((title, full_url, card_text))
                    except Exception:
                        continue

            if len(page_jobs) == 0 and not page_seen_raw:
                # F-31: nothing at all on this page. Classify it (challenge /
                # render failure) and recover or stop honestly - a page that was
                # never a listing page must not be reported as "pagination
                # control not recognised".
                outcome = _recover_blank_page(page, current_page_url, page_num,
                                              clear_wait_s)
                if outcome == "cleared":
                    recover_cleared += 1
                    if recover_cleared <= 2:
                        logger.info("Page %d recovered; re-harvesting it",
                                    page_num)
                        continue
                    # F-35b: bounded recovery - a page that still renders
                    # empty after two recoveries is the end of the board (or
                    # a hard wall), not a transient glitch.
                    logger.info("Page %d stayed empty after %d recoveries; "
                                "treating it as the end", page_num,
                                recover_cleared)
                if outcome == "challenge":
                    stop_reason = ("bot protection re-engaged on page %d; no human "
                                   "clearance observed within the wait window "
                                   "(last complete page %d)"
                                   % (page_num, last_good_page))
                elif probe_pending_end:
                    stop_reason = ("no next-page control recognised on page %d "
                                   "(last complete page %d); end confirmed by an "
                                   "out-of-range probe" % (page_num, last_good_page))
                else:
                    stop_reason = ("page %d returned no listing content and no "
                                   "pagination even after a reload (render failure "
                                   "or undetected bot wall; last complete page %d)"
                                   % (page_num, last_good_page))
                logger.info("Harvest stopped: %s", stop_reason)
                break

            logger.info("Page %d found %d job listing(s)", page_num, len(page_jobs))

            # F-27: a paging step that lands back on the identical listing means
            # the board refused to advance (a click that did nothing, a clamped
            # parameter, a JS-only pager). That is a FAILED ADVANCE, not the end
            # of the board: retry with a different mechanism - URL-based paging
            # only, skipping the DOM clicks that just failed - and only call it
            # the end after three such attempts.
            re_served = bool(page_seen_raw) and any(
                page_seen_raw == r for r in recent_raws)
            recent_raws.append(page_seen_raw)
            del recent_raws[:-4]
            if page_jobs:
                last_good_page = page_num
                last_good_count = len(page_jobs)
                page_size_max = max(page_size_max, len(page_jobs))
                probe_pending_end = False
                recover_cleared = 0
            if re_served:
                mis_advances += 1
                # F-37b: a landing that re-served the previous listing was a
                # DENIED advance, not a visited page - un-try it so the board's
                # own href (the only key a signed pager accepts) stays
                # retryable after a cool-down or a mis-advance retry.
                tried_urls.discard(current_page_url)
                if mis_advances >= 3:
                    # F-37: three refused advances right after a long request
                    # burst is also what a bot edge's soft denial / stale edge
                    # cache looks like (your round-12 evidence: the live RW NL
                    # pager runs to 60 pages while rev-10 stopped at 49). One
                    # polite cool-down per run: pause, reload, retry the whole
                    # advance chain before spending probes or accepting the end.
                    if (cooldowns_used < len(_COOLDOWN_STEPS_S)
                            and page_size_max >= 5
                            and last_good_count >= page_size_max - 1):
                        # F-38: a bot edge's rate-limit window can outlast one
                        # 15 s pause (your round-13 run: re-serve stop at page
                        # 47 while the live pager runs to 60). Escalate
                        # politely - 15 s, then 45 s, then 90 s, at most three
                        # pauses per run, all of it pure waiting - and retry
                        # the whole advance chain after each pause before
                        # spending probes or accepting the end.
                        delay = _COOLDOWN_STEPS_S[cooldowns_used]
                        cooldowns_used += 1
                        mis_advances = 0
                        force_url_advance = False
                        logger.info("Assisted pagination: 3 refused advances on a "
                                    "full page %d - cool-down %d/3: waiting %.0fs "
                                    "then retrying the advance chain",
                                    page_num, cooldowns_used, delay)
                        try:
                            page.wait_for_timeout(int(delay * 1000))
                            page.reload(wait_until="domcontentloaded", timeout=30000)
                            time.sleep(3.0)
                        except Exception:
                            pass
                        continue
                    # F-35c: same false-end logic as the no-next branch - a
                    # FULL last page plus three refused advances can still be
                    # a board glitch (your round-11 run: 490 jobs, re-serve
                    # stop at page 49 on a board you believe holds 500+).
                    # Spend one synthesised-URL probe before accepting the
                    # end; new jobs resume the harvest, a re-serve or blank
                    # confirms it.
                    if (probes_left
                            and page_size_max >= 5
                            and last_good_count >= page_size_max - 1):
                        probe_url = next_page_url(page.url, page_num)
                        if probe_url and probe_url not in tried_urls:
                            probes_left -= 1
                            tried_urls.add(probe_url)
                            probe_pending_end = True
                            logger.info("Assisted pagination: end-of-board probe %d/4 -> %s",
                                                4 - probes_left, probe_url)
                            try:
                                page.goto(probe_url, wait_until="domcontentloaded",
                                          timeout=20000)
                                time.sleep(3.0)
                                current_page_url = page.url
                                tried_urls.add(current_page_url)
                                force_url_advance = True
                                mis_advances = 0
                                continue
                            except Exception:
                                pass
                    # page_num is the NEXT-page counter, so quoting it here read
                    # one (or with clamp oscillation, two) past the true end and
                    # looked like a hidden cap (your round-8 question). Quote the
                    # last page that actually delivered jobs instead.
                    stop_reason = ("board re-served the same listing after %d paging "
                                   "attempts (last complete page %d); no further "
                                   "pages reachable" % (mis_advances, last_good_page))
                    logger.info("Harvest stopped: %s", stop_reason)
                    break
                # F-37d: when the denied landing URL IS the advance target
                # (its paging value equals the counter), re-request that exact
                # URL politely before the retry chain drifts to synthesised
                # stale-token URLs - a signed board clamps those to its
                # visible window, while a bot edge's soft denial (round-12 RW
                # NL evidence: pager runs to 60 while rev-10 stopped at 49)
                # typically releases on the next same-href request.
                if _paging_value(current_page_url) == page_num:
                    logger.info(
                        "Page %d re-served the previous listing; re-requesting the "
                        "denied href %s politely (attempt %d/3)",
                        page_num, current_page_url, mis_advances)
                    try:
                        page.goto(current_page_url,
                                  wait_until="domcontentloaded", timeout=20000)
                        time.sleep(3.0)
                        current_page_url = page.url
                        tried_urls.add(current_page_url)
                        force_url_advance = True
                        continue
                    except Exception:
                        pass
                force_url_advance = True
                logger.info(
                    "Page %d re-served the previous listing; retrying with URL-based "
                    "paging (attempt %d/3)", page_num, mis_advances)
            else:
                mis_advances = 0

            if len(page_jobs) == 0 and re_served:
                pass                      # handled by the failed-advance retry below
            elif len(page_jobs) == 0:
                # F-27: before calling the board empty, try another board-owned
                # paging href. A failed/synthesised advance re-serves an old
                # page, which would otherwise read as two empty pages and stop
                # a harvest that still has pages left.
                cands = paging_href_candidates(
                    page, current_page_url,
                    tried_urls)
                if cands:
                    nxt = cands[0]
                    tried_urls.add(nxt)
                    logger.info("Page %d empty; retrying with the board's own href %s",
                                page_num, nxt)
                    try:
                        page.goto(nxt, wait_until="domcontentloaded", timeout=20000)
                        time.sleep(3.0)
                        current_page_url = page.url
                        tried_urls.add(current_page_url)
                        continue
                    except Exception:
                        pass
                consecutive_empty_pages += 1
                if consecutive_empty_pages >= 2:
                    # F-22: repeated empty pages mean the advance strategy never
                    # reached new content (the board ignored the synthesised
                    # parameter, or the click hit a dead control). Say so
                    # instead of letting a 1-page harvest read as a full one.
                    stop_reason = ("no new listings on %d consecutive pages - "
                                   "pagination control not recognised "
                                   "(last complete page %d)"
                                   % (consecutive_empty_pages, last_good_page))
                    logger.info("Early stopping pagination: %s", stop_reason)
                    break
            else:
                consecutive_empty_pages = 0

            # Ingest harvested jobs
            for title, job_url, card_text in page_jobs:
                if is_filter_or_facet_title(title, job_url):
                    continue
                if is_noise_cta_title(title):
                    continue
                if is_chrome_url(job_url):
                    continue

                extracted_loc = "Unknown"
                remote_type = "onsite"
                combined_context = f"{title}\n{card_text}"

                # Extract location from card
                loc_match = re.search(r"(?:Location|Locatie|Ort|Lieu|Ubicación|Localisation):\s*([^\n\r]+)", card_text, re.I)
                if loc_match:
                    extracted_loc = loc_match.group(1).strip()
                else:
                    for line in card_text.splitlines():
                        line_s = line.strip()
                        if line_s and line_s != title:
                            candidate = scanner._sanitize_job_location(line_s, seed_name)
                            if candidate and candidate != "Unknown":
                                extracted_loc = candidate
                                break

                # Detect Remote
                if re.search(r"\b(remote|work from home|fully remote|100% remote)\b", card_text, re.I):
                    remote_type = "remote"
                elif re.search(r"\b(hybrid|flexible remote)\b", card_text, re.I):
                    remote_type = "hybrid"

                # Country mapping
                country = country_from_location(extracted_loc)
                if not country or country == "Unknown":
                    # Determine country strictly from portal URL domain first, then seed name
                    parsed_job = urlparse(job_url)
                    host = parsed_job.netloc.lower()
                    path = parsed_job.path.lower()
                    if host.endswith(".nl") or "/nl/" in path:
                        country = "Netherlands"
                    elif host.endswith(".ie") or "/ie/" in path:
                        country = "Ireland"
                    elif host.endswith(".de") or "/de/" in path:
                        country = "Germany"
                    elif host.endswith(".fr") or "/fr/" in path:
                        country = "France"
                    elif host.endswith(".co.uk") or "/uk/" in path:
                        country = "United Kingdom"
                    elif "NL" in seed_name or ".nl" in url:
                        country = "Netherlands"
                    elif "IE" in seed_name or ".ie" in url:
                        country = "Ireland"
                    elif "DE" in seed_name or ".de" in url:
                        country = "Germany"
                    elif "UK" in seed_name or ".co.uk" in url:
                        country = "United Kingdom"
                    else:
                        country = "Global"

                # Sponsorship & Relocation
                det_res = detector.detect(combined_context)
                visa_support = det_res.get("visa", {})
                reloc_support = det_res.get("relocation", {})

                v_verdict = visa_support.get("verdict", VERDICT_UNKNOWN)
                v_conf = visa_support.get("confidence", 0.0)
                r_verdict = reloc_support.get("verdict", VERDICT_UNKNOWN)

                bc_verdict = detect_blue_card(detector, combined_context)

                exp_info = extract_experience(combined_context, title)
                exp_level = exp_info.get("level", "Unknown")
                exp_req = exp_info.get("required", "Unknown")
                exp_min = exp_info.get("min_years") or None
                exp_src = exp_info.get("source", "none")
                terms_res = extract_terms(title, extracted_loc, exp_level, combined_context, "")

                job_record = {
                    "title": title,
                    "company": seed_name,
                    "country": country,
                    "country_source": "auto",
                    "location": extracted_loc,
                    "raw_location": extracted_loc,
                    "url": job_url,
                    "ats_source": "assisted_browser",
                    "source_type": "recruiter" if any(x in seed_name.lower() for x in ("recruitment", "walters", "hays", "randstad", "page")) else "direct_employer",
                    "source_subtype": "recruiter" if any(x in seed_name.lower() for x in ("recruitment", "walters", "hays", "randstad", "page")) else "direct",
                    "source_name": seed_name,
                    "description": "",
                    "remote_type": remote_type,
                    "experience_level": exp_level,
                    "experience_required": exp_req,
                    "experience_min_years": exp_min,
                    "experience_source": exp_src,
                    "category": terms_res["category"],
                    "domain": terms_res["domain"],
                    "visa_sponsorship": "Y" if v_verdict == VERDICT_YES else ("N" if v_verdict == VERDICT_NO else "Unknown"),
                    "relocation_support": "Y" if r_verdict == VERDICT_YES else ("N" if r_verdict == VERDICT_NO else "Unknown"),
                    "eu_blue_card_verdict": bc_verdict,
                    "terms": terms_res["terms"],
                }

                try:
                    already = conn.execute(
                        "SELECT 1 FROM jobs WHERE url = ?", (job_url,)).fetchone()
                    upsert_job(conn, job_record, commit=False)
                    ingested_count += 1
                    if already:
                        dup_count += 1
                    else:
                        new_count += 1
                        harvest_rows.append({
                            "title": title, "company": seed_name,
                            "country": country, "location": extracted_loc,
                            "url": job_url, "category": job_record["category"],
                            "domain": job_record["domain"],
                            "source_type": job_record["source_type"],
                            "source_subtype": job_record["source_subtype"],
                            "source_name": seed_name,
                            "ats_source": "assisted_browser",
                            "remote_type": remote_type,
                            "experience_level": exp_level,
                            "visa_sponsorship": job_record["visa_sponsorship"],
                            "relocation_support": job_record["relocation_support"],
                        })
                except Exception as ex:
                    logger.debug("Error upserting assisted job %s: %s", job_url, ex)

            conn.commit()

            # Attempt pagination to next page
            next_clicked = False
            # After a failed advance, skip the DOM-click checks (1-3) that just
            # produced nothing and go straight to URL-based paging (3.5 / 4).
            skip_dom = force_url_advance
            force_url_advance = False
            # F-32: some boards render the pager (and late cards) only once it
            # scrolls into view. One cheap scroll-to-bottom before the DOM checks
            # keeps a lazy pager from looking like "no pagination control".
            if not skip_dom:
                try:
                    page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                    time.sleep(0.8)
                except Exception:
                    pass

            # Check 1: In-page DOM JavaScript Next click (guarantees click regardless of scroll or CSS overlay)
            try:
                js_click_result = None if skip_dom else page.evaluate("""(targetPageNum) => {
                    // Try targeting explicit pagination links by text or data attribute
                    const pageLinks = Array.from(document.querySelectorAll('a, button'));
                    for (const el of pageLinks) {
                        const txt = (el.textContent || '').trim();
                        const rel = el.getAttribute('rel') || '';
                        const aria = el.getAttribute('aria-label') || '';
                        const dataPage = el.getAttribute('data-page') || '';
                        const cls = el.className || '';

                        // Exact target page number
                        if (txt === String(targetPageNum) || dataPage === String(targetPageNum) || dataPage === String(targetPageNum - 1)) {
                            if (!el.classList.contains('disabled') && !el.hasAttribute('disabled')) {
                                el.scrollIntoView({block: 'center'});
                                el.click();
                                return true;
                            }
                        }
                    }

                    // Try next sibling of active page number
                    const active = document.querySelector('.pagination .active, .pagination [aria-current="page"], nav [aria-current="page"], [class*="pagination"] .current, [class*="page-current"]');
                    if (active) {
                        let nextEl = active.nextElementSibling;
                        while (nextEl) {
                            const link = (nextEl.tagName === 'A' || nextEl.tagName === 'BUTTON') ? nextEl : nextEl.querySelector('a, button');
                            if (link && !link.classList.contains('disabled') && !link.hasAttribute('disabled')) {
                                link.scrollIntoView({block: 'center'});
                                link.click();
                                return true;
                            }
                            nextEl = nextEl.nextElementSibling;
                        }
                    }

                    // Try next arrow button or link
                    const nextArrow = document.querySelector(
                        'a[rel="next"], [aria-label*="Next" i], [aria-label*="Weiter" i], [aria-label*="Volgende" i], ' +
                        '.pagination .next, [class*="pagination"] [class*="next"], [class*="pagination__arrow--next"], ' +
                        'button[class*="next" i], a[class*="next" i], a[data-page-dir="next"]'
                    );
                    if (nextArrow && !nextArrow.classList.contains('disabled')) {
                        nextArrow.scrollIntoView({block: 'center'});
                        nextArrow.click();
                        return true;
                    }
                    return false;
                }""", page_num + 1)
                if js_click_result:
                    next_clicked = True
            except Exception:
                pass

            # Check 2: Target specific next page number link (e.g. "2", "3", "6", "11", etc.)
            if not next_clicked and not skip_dom:
                target_page_str = str(page_num + 1)
                try:
                    num_btn = (
                        page.query_selector(f"nav a:text-is('{target_page_str}')") or
                        page.query_selector(f"ul.pagination a:text-is('{target_page_str}')") or
                        page.query_selector(f".pagination a:text-is('{target_page_str}')") or
                        page.query_selector(f"[class*='pagination'] a:text-is('{target_page_str}')") or
                        page.query_selector(f"a[data-page='{target_page_str}']") or
                        page.query_selector(f"a[data-page='{page_num}']") or
                        page.query_selector(f"a:text-is('{target_page_str}')")
                    )
                    if num_btn and num_btn.is_visible():
                        num_btn.scroll_into_view_if_needed()
                        num_btn.click()
                        next_clicked = True
                except Exception:
                    pass

            # Check 3: Next chevron / button / arrow
            if not next_clicked and not skip_dom:
                next_selectors = [
                    "a[rel='next']",
                    "a[aria-label*='Next' i]",
                    "button[aria-label*='Next' i]",
                    "a[aria-label*='Volgende' i]",
                    "button[aria-label*='Volgende' i]",
                    "a[class*='pagination__arrow--next']",
                    "button[class*='pagination__arrow--next']",
                    "a.next",
                    "button.next",
                    "a:has-text('›')",
                    "a:has-text('»')",
                    "a:has-text('>')",
                    "button:has-text('Next')",
                    "a:has-text('Next')",
                    "a:has-text('Volgende')",
                    "button:has-text('Volgende')",
                    "button:has-text('Load More')",
                    "button:has-text('Show more')",
                    "button:has-text('Meer laden')",
                    "a:has-text('Meer laden')",
                    "a:has-text('Weiter')",
                    "button:has-text('Weiter')",
                    "a[aria-label*='Weiter' i]",
                    "button[aria-label*='Weiter' i]",
                    "a[aria-label*='Nächste' i]",
                    "button[aria-label*='Nächste' i]",
                ]
                for sel in next_selectors:
                    try:
                        btn = page.query_selector(sel)
                        if btn and btn.is_visible():
                            btn.scroll_into_view_if_needed()
                            btn.click()
                            next_clicked = True
                            break
                    except Exception:
                        continue

            # Check 3.5 (F-27): the board's own paging hrefs, ascending. This is
            # what carries a harvest past a numbered pager's visible window.
            if not next_clicked:
                cands = paging_href_candidates(
                    page, current_page_url,
                    tried_urls)
                if cands:
                    nxt = cands[0]
                    tried_urls.add(nxt)
                    try:
                        page.goto(nxt, wait_until="domcontentloaded", timeout=20000)
                        next_clicked = True
                    except Exception:
                        pass

            # Check 4: generic query-parameter navigation. Increments the
            # board's own paging parameter when the URL already carries one;
            # otherwise probes `p`. No host-name rules (F-25, guide §15.9): a
            # board that ignores the synthesised parameter is caught by the
            # no-progress stop above, not special-cased here.
            if not next_clicked and (len(page_jobs) >= 5 or skip_dom):
                try:
                    next_url = next_page_url(page.url, page_num)
                    if next_url:
                        page.goto(next_url, wait_until="domcontentloaded", timeout=20000)
                        next_clicked = True
                except Exception:
                    pass

            if not next_clicked:
                # F-35: a FULL last-complete page plus a missing next control is
                # suspicious - boards sometimes render a false end mid-listing
                # (stale result count, JS pager glitch). Probe the synthesised
                # next URL (budget: 2 loads per run) before accepting the end:
                # new jobs resume the harvest, nothing confirms the end.
                if (probes_left
                        and last_good_page >= page_num - 1
                        and page_size_max >= 5
                        and last_good_count >= page_size_max - 1):
                    probe_url = next_page_url(page.url, page_num)
                    if probe_url and probe_url not in tried_urls:
                        probes_left -= 1
                        tried_urls.add(probe_url)
                        probe_pending_end = True
                        logger.info("Assisted pagination: end-of-board probe %d/4 -> %s",
                                            4 - probes_left, probe_url)
                        try:
                            page.goto(probe_url, wait_until="domcontentloaded",
                                      timeout=20000)
                            time.sleep(3.0)
                            current_page_url = page.url
                            tried_urls.add(current_page_url)
                            force_url_advance = True
                            continue
                        except Exception:
                            pass
                stop_reason = ("no next-page control recognised on page %d "
                               "(last complete page %d)"
                               % (page_num, last_good_page))
                logger.info("Assisted pagination: %s", stop_reason)
                break

            time.sleep(3.0)
            try:
                page.wait_for_load_state("domcontentloaded", timeout=10000)
            except Exception:
                pass

            current_page_url = page.url
            tried_urls.add(current_page_url)
            # A re-served listing is a wasted load, not a page: keeping the
            # counter on the real page number is what lets the mis-advance limit
            # (3) fire before the page cap masks the honest stop reason.
            if not re_served:
                page_num += 1


        # F-34: "Pages read" must mean complete listing pages, not browser
        # loads. Clamp/redirect phantoms stay visible as `loads` in the log
        # and report, never as the user-facing page count.
        pages_visited = last_good_page

        context.close()
        browser.close()

    # Log execution in scan_runs and scan_log so the Tools tab and DB history track it
    try:
        from datetime import datetime, timezone
        from sponsorscout.db.database import (
            start_scan_run,
            finish_scan_run,
            record_scan_log_rows,
            record_scan_event,
        )
        run_id = run_started.strftime("%Y%m%dT%H%M%S")
        db_path = db_path or getattr(conn, "_db_path", None)
        # F-39: the format string repeated the month and dropped the day
        # ("%Y-%m-%m"), so every run row claimed e.g. 2026-10-10 for a
        # 2026-10-23 scan (your round-13 CSVs). Real calendar day now, on the
        # same UTC clock as run_id, the event timeline and the DB defaults.
        started_s = run_started.strftime("%Y-%m-%d %H:%M:%S")
        finished_s = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        duration_s = (datetime.now(timezone.utc) - run_started).total_seconds()
        # Check if conn has path attribute or fallback to direct execute
        conn.execute(
            """INSERT INTO scan_runs (run_id, method, ats_companies, career_companies, status, started_at, finished_at,
                                     targets_ok, targets_empty, targets_error, jobs_found, jobs_quarantined, jobs_duplicates, error)
               VALUES (?, 'assisted', 0, 1, 'completed', ?, ?,
                       ?, ?, 0, ?, 0, ?, '')
               ON CONFLICT(run_id) DO UPDATE SET
                 status='completed', jobs_found=excluded.jobs_found,
                 jobs_duplicates=excluded.jobs_duplicates,
                 finished_at=excluded.finished_at""",
            (run_id, started_s, finished_s,
             1 if ingested_count > 0 else 0, 0 if ingested_count > 0 else 1,
             ingested_count, dup_count),
        )
        conn.execute(
            """INSERT INTO scan_log
               (run_id, scanner, seed_name, company, source_type, target_country,
                status, provider, jobs_found, quarantined, duplicates,
                rejected_scope, error, diagnostics, duration_sec, seed_url)
               VALUES (?, 'assisted_browser', ?, ?, 'recruiter', ?,
                       ?, 'AssistedBrowser', ?, 0, ?, 0, '', ?, ?, ?)""",
            (
                run_id,
                seed_name,
                seed_name,
                country if 'country' in locals() else "Global",
                "OK" if ingested_count > 0 else "EMPTY",
                ingested_count,
                dup_count,
                f"Harvested {ingested_count} jobs ({new_count} new, {dup_count} "
                f"already present) across {pages_visited} page(s) "
                f"({loads} browser load(s) incl. retries); stop: {stop_reason}",
                duration_s,
                url,
            ),
        )
        conn.execute(
            """INSERT INTO scan_events (run_id, level, phase, company, message)
               VALUES (?, 'info', 'assisted_ingestion', ?, ?)""",
            (run_id, seed_name, f"Assisted browser session completed. Harvested {ingested_count} job vacancies from {url}."),
        )
        conn.commit()

        # F-36: CSV parity - an assisted run leaves the same file set behind as
        # a regular scan run (job list, recruiter view, quarantine, scan log,
        # errors), utf-8-sig so Excel/LibreOffice open them correctly.
        try:
            import csv as _csv
            from sponsorscout import paths as _paths
            out_dir = _paths.ensure_scan_output_dir()
            job_fields = ["title", "company", "country", "location", "url",
                          "category", "domain", "source_type",
                          "source_subtype", "source_name", "ats_source",
                          "remote_type", "experience_level",
                          "visa_sponsorship", "relocation_support"]
            base = out_dir / f"{run_id}_career_jobs.csv"
            for path, rows in (
                    (base, harvest_rows),
                    (base.with_name(base.stem + "_recruiter.csv"),
                     [r for r in harvest_rows
                      if r["source_subtype"] == "recruiter"]),
            ):
                with open(path, "w", encoding="utf-8-sig", newline="") as f:
                    wcsv = _csv.DictWriter(f, fieldnames=job_fields)
                    wcsv.writeheader()
                    wcsv.writerows(rows)
            with open(base.with_name(base.stem + "_quarantine.csv"), "w",
                      encoding="utf-8-sig", newline="") as f:
                _csv.DictWriter(f, fieldnames=["title", "company", "url",
                                               "reason"]).writeheader()
            with open(base.with_name(base.stem + "_errors.csv"), "w",
                      encoding="utf-8-sig", newline="") as f:
                _csv.DictWriter(f, fieldnames=["error", "url",
                                               "detail"]).writeheader()
            if db_path:
                from sponsorscout.db import database as _dbmod
                with open(base.with_name(base.stem + "_scan_log.csv"), "w",
                          encoding="utf-8-sig", newline="") as f:
                    f.write(_dbmod.export_scan_run_csv(db_path, run_id))
            logger.info("Assisted-run CSV set written to %s", out_dir)
        except Exception as ex:
            logger.warning("Could not write assisted-run CSVs: %s", ex)
    except Exception as ex:
        logger.debug("Could not record scan_runs / scan_log for assisted ingestion: %s", ex)

    LAST_INGESTION_REPORT.update(
        url=url,
        ingested=new_count,
        harvested=ingested_count,
        duplicates=dup_count,
        pages_visited=pages_visited,
        loads=loads,
        stop_reason=stop_reason,
    )
    logger.info("Assisted ingestion finished. Harvested %d (%d new, %d already "
                "present); stop: %s", ingested_count, new_count, dup_count,
                stop_reason)
    return new_count


def is_web_url(url: str | None) -> bool:
    """Return True if url is an http/https URL."""
    if not url or not isinstance(url, str):
        return False
    try:
        p = urlparse(url.strip())
        return p.scheme in ("http", "https") and bool(p.netloc)
    except Exception:
        return False


def blocked_portals_from_errors_csv(csv_path) -> list[dict[str, str]]:
    """Parse a scan errors CSV and return all distinct bot-blocked portal targets."""
    if not csv_path or not os.path.exists(csv_path):
        return []
    import csv
    results = []
    seen = set()
    try:
        with open(csv_path, newline="", encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                msg = str(row.get("Message") or "")
                url = str(row.get("Seed URL") or "").strip()
                if not is_web_url(url):
                    continue
                if url in seen:
                    continue
                # Specific bot-protection failure marker
                if "blocked by bot protection:" in msg.lower():
                    seen.add(url)
                    results.append({
                        "seed_name": str(row.get("Seed Name") or "").strip(),
                        "url": url,
                        "reason": msg,
                    })
    except Exception as e:
        logger.warning("Error reading errors CSV %s: %s", csv_path, e)
    return results


def blocked_portals_from_summary(summary: dict) -> list[dict[str, str]]:
    """Inspect a finished scan summary for bot-blocked career portals (never ATS)."""
    if not summary or not isinstance(summary, dict):
        return []
    artifacts = summary.get("artifacts") or {}
    career_artifacts = artifacts.get("career") or {}
    career_errors = career_artifacts.get("errors")
    if not career_errors:
        return []
    return blocked_portals_from_errors_csv(career_errors)


def open_in_default_browser(url: str) -> bool:
    """Open a blocked portal URL directly in the user's default system browser."""
    if not is_web_url(url):
        return False
    try:
        return bool(webbrowser.open_new_tab(url))
    except Exception as e:
        logger.warning("Could not open URL in external browser: %s", e)
        return False
