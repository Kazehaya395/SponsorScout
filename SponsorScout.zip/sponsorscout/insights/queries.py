"""SQL queries and data aggregation helpers for the Insights tab."""
from __future__ import annotations

import sqlite3
from typing import Any

from sponsorscout.db.database import get_connection


def _build_filter_clause(
    run_id: str = "",
    country: str = "",
    source_subtype: str = "",  # "direct", "recruiter", or "" (all)
    category: str = "",
    domain: str = "",
) -> tuple[str, list[Any]]:
    clauses = ["verified_active = 1", "is_expired = 0"]
    params: list[Any] = []

    if run_id and run_id.lower() not in ("all", ""):
        clauses.append("run_id = ?")
        params.append(run_id)

    if country and country.lower() not in ("all", "all countries", ""):
        clauses.append("country = ?")
        params.append(country)

    if source_subtype and source_subtype.lower() not in ("all", ""):
        clauses.append("source_subtype = ?")
        params.append(source_subtype)

    if category and category.lower() not in ("all", "all categories", ""):
        if category == "Other":
            clauses.append("(category IS NULL OR category = '' OR category = 'Other')")
        else:
            clauses.append("category = ?")
            params.append(category)

    if domain and domain.lower() not in ("all", "all domains", ""):
        if domain == "Unknown":
            clauses.append("(domain IS NULL OR domain = '' OR domain = 'Unknown')")
        else:
            clauses.append("domain = ?")
            params.append(domain)

    return " WHERE " + " AND ".join(clauses) if clauses else "", params


def get_insights_coverage(
    db_path, run_id="", country="", source_subtype="", category="", domain=""
) -> dict[str, Any]:
    """Return coverage statistics: total jobs, categorized jobs, jobs with skills."""
    where, params = _build_filter_clause(run_id, country, source_subtype, category=category, domain=domain)
    with get_connection(db_path) as conn:
        total = conn.execute(f"SELECT COUNT(*) FROM jobs{where}", params).fetchone()[0]
        categorized = conn.execute(
            f"SELECT COUNT(*) FROM jobs{where}{' AND' if where else ' WHERE'} category IS NOT NULL AND category != 'Other'",
            params,
        ).fetchone()[0]
        
        # Jobs with at least one skill term
        skill_where = where.replace("verified_active", "j.verified_active").replace("is_expired", "j.is_expired")
        if run_id and run_id.lower() not in ("all", ""):
            skill_where = skill_where.replace("run_id", "j.run_id")
        if country and country.lower() not in ("all", "all countries", ""):
            skill_where = skill_where.replace("country", "j.country")
        if source_subtype and source_subtype.lower() not in ("all", ""):
            skill_where = skill_where.replace("source_subtype", "j.source_subtype")
        if category and category.lower() not in ("all", "all categories", ""):
            skill_where = skill_where.replace("category", "j.category")
        if domain and domain.lower() not in ("all", "all domains", ""):
            skill_where = skill_where.replace("domain", "j.domain")

        skills_count = conn.execute(
            f"""SELECT COUNT(DISTINCT j.id) FROM jobs j
                JOIN job_terms t ON j.id = t.job_id
                {skill_where}{' AND' if skill_where else ' WHERE'} t.kind = 'skill'""",
            params,
        ).fetchone()[0]

    return {
        "total_jobs": total,
        "categorized_jobs": categorized,
        "jobs_with_skills": skills_count,
        "category_coverage_pct": round(categorized / total * 100, 1) if total else 0.0,
        "skill_coverage_pct": round(skills_count / total * 100, 1) if total else 0.0,
    }


def get_jobs_by_category(
    db_path, run_id="", country="", source_subtype="", domain=""
) -> list[tuple[str, int]]:
    """Return job counts grouped by category, descending."""
    where, params = _build_filter_clause(run_id, country, source_subtype, domain=domain)
    with get_connection(db_path) as conn:
        rows = conn.execute(
            f"""SELECT COALESCE(NULLIF(category, ''), 'Other') as cat, COUNT(*) as cnt
                FROM jobs{where}
                GROUP BY cat ORDER BY cnt DESC, cat ASC""",
            params,
        ).fetchall()
        return [(r[0], r[1]) for r in rows]


def get_jobs_by_domain(
    db_path, run_id="", country="", source_subtype="", category=""
) -> list[tuple[str, int]]:
    """Return job counts grouped by employer domain, descending."""
    where, params = _build_filter_clause(run_id, country, source_subtype, category=category)
    with get_connection(db_path) as conn:
        rows = conn.execute(
            f"""SELECT COALESCE(NULLIF(domain, ''), 'Unknown') as dom, COUNT(*) as cnt
                FROM jobs{where}
                GROUP BY dom ORDER BY cnt DESC, dom ASC""",
            params,
        ).fetchall()
        return [(r[0], r[1]) for r in rows]


def get_top_skills(
    db_path, limit: int = 15, run_id="", country="", source_subtype="", category="", domain=""
) -> list[tuple[str, int]]:
    """Return most frequent skill terms found in JDs, descending."""
    where, params = _build_filter_clause(run_id, country, source_subtype, category=category, domain=domain)
    j_where = where.replace("verified_active", "j.verified_active").replace("is_expired", "j.is_expired")
    if run_id and run_id.lower() not in ("all", ""):
        j_where = j_where.replace("run_id", "j.run_id")
    if country and country.lower() not in ("all", "all countries", ""):
        j_where = j_where.replace("country", "j.country")
    if source_subtype and source_subtype.lower() not in ("all", ""):
        j_where = j_where.replace("source_subtype", "j.source_subtype")
    if category and category.lower() not in ("all", "all categories", ""):
        j_where = j_where.replace("category", "j.category")
    if domain and domain.lower() not in ("all", "all domains", ""):
        j_where = j_where.replace("domain", "j.domain")

    with get_connection(db_path) as conn:
        rows = conn.execute(
            f"""SELECT t.term, COUNT(DISTINCT j.id) as cnt
                FROM job_terms t
                JOIN jobs j ON t.job_id = j.id
                {j_where}{' AND' if j_where else ' WHERE'} t.kind = 'skill'
                GROUP BY t.term ORDER BY cnt DESC, t.term ASC""",
            params,
        ).fetchall()
        return [(r[0], r[1]) for r in rows]


def get_segregated_skills(
    db_path, run_id="", country="", source_subtype="", category="", domain=""
) -> dict[str, list[tuple[str, int]]]:
    """Return top skills segregated into 'technical' and 'soft' lists."""
    from sponsorscout.insights.terms import _SOFT_SKILL_GROUPS, _find_data_file
    import csv

    soft_terms = set()
    skill_file = _find_data_file("skills_dictionary.csv")
    if skill_file.exists():
        try:
            with open(skill_file, "r", encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    if r.get("group") in _SOFT_SKILL_GROUPS:
                        soft_terms.add(r.get("term"))
        except Exception:
            pass

    all_skills = get_top_skills(
        db_path, run_id=run_id, country=country, source_subtype=source_subtype, category=category, domain=domain
    )
    tech = []
    soft = []
    for term, count in all_skills:
        if term in soft_terms:
            soft.append((term, count))
        else:
            tech.append((term, count))

    return {
        "all": all_skills,
        "technical": tech,
        "soft": soft,
    }


def get_sponsorship_by_category(
    db_path, run_id="", country="", source_subtype="", category="", domain=""
) -> list[dict[str, Any]]:
    """Return sponsorship and relocation counts per category (Yes / No / Unknown separate)."""
    where, params = _build_filter_clause(run_id, country, source_subtype, category=category, domain=domain)
    with get_connection(db_path) as conn:
        rows = conn.execute(
            f"""SELECT COALESCE(NULLIF(category, ''), 'Other') as cat,
                       SUM(CASE WHEN visa_sponsorship = 'Y' THEN 1 ELSE 0 END) as visa_yes,
                       SUM(CASE WHEN visa_sponsorship = 'N' THEN 1 ELSE 0 END) as visa_no,
                       SUM(CASE WHEN visa_sponsorship NOT IN ('Y', 'N') THEN 1 ELSE 0 END) as visa_unk,
                       SUM(CASE WHEN relocation_support = 'Y' THEN 1 ELSE 0 END) as reloc_yes,
                       SUM(CASE WHEN relocation_support = 'N' THEN 1 ELSE 0 END) as reloc_no,
                       SUM(CASE WHEN relocation_support NOT IN ('Y', 'N') THEN 1 ELSE 0 END) as reloc_unk,
                       COUNT(*) as total
                FROM jobs{where}
                GROUP BY cat ORDER BY total DESC, cat ASC""",
            params,
        ).fetchall()

        return [
            {
                "category": r[0],
                "visa_yes": r[1] or 0,
                "visa_no": r[2] or 0,
                "visa_unk": r[3] or 0,
                "reloc_yes": r[4] or 0,
                "reloc_no": r[5] or 0,
                "reloc_unk": r[6] or 0,
                "total": r[7] or 0,
            }
            for r in rows
        ]


def get_country_category_matrix(
    db_path, top_countries: int = 8, top_categories: int = 6, run_id="", source_subtype=""
) -> dict[str, Any]:
    """Return cross-tabulation matrix of Country x Category counts."""
    where, params = _build_filter_clause(run_id, "", source_subtype)
    with get_connection(db_path) as conn:
        # Get top countries
        c_rows = conn.execute(
            f"""SELECT country, COUNT(*) as cnt FROM jobs{where}
                {' AND' if where else ' WHERE'} country IS NOT NULL AND country != ''
                GROUP BY country ORDER BY cnt DESC LIMIT ?""",
            params + [top_countries],
        ).fetchall()
        countries = [r[0] for r in c_rows]

        # Get top categories
        cat_rows = conn.execute(
            f"""SELECT COALESCE(NULLIF(category, ''), 'Other') as cat, COUNT(*) as cnt
                FROM jobs{where}
                GROUP BY cat ORDER BY cnt DESC LIMIT ?""",
            params + [top_categories],
        ).fetchall()
        categories = [r[0] for r in cat_rows]

        matrix = {c: {cat: 0 for cat in categories} for c in countries}
        if countries and categories:
            placeholders_c = ",".join("?" for _ in countries)
            placeholders_cat = ",".join("?" for _ in categories)
            m_where = (f"{where} AND" if where else "WHERE") + f" country IN ({placeholders_c})"
            rows = conn.execute(
                f"""SELECT country, COALESCE(NULLIF(category, ''), 'Other') as cat, COUNT(*)
                    FROM jobs {m_where}
                    GROUP BY country, cat""",
                params + countries,
            ).fetchall()
            for c, cat, cnt in rows:
                if c in matrix and cat in matrix[c]:
                    matrix[c][cat] = cnt

    return {
        "countries": countries,
        "categories": categories,
        "matrix": matrix,
    }


def backfill_existing_job_terms(db_path, force_all: bool = False) -> int:
    """Backfill/refresh categories, domains, and extracted skill terms for jobs in the database.
    
    Reads title, support evidence, description, location, and industry to extract rich
    skills and granular category classifications.
    """
    from sponsorscout.insights.terms import extract_terms

    with get_connection(db_path) as conn:
        cols = [c[1] for c in conn.execute("PRAGMA table_info(jobs)").fetchall()]
        ev_col = "support_evidence" if "support_evidence" in cols else "''"
        
        sql = f"SELECT id, title, location, experience_level, description, industry, {ev_col} FROM jobs"
        if not force_all:
            sql += " WHERE category IS NULL OR category = 'Other' OR domain IS NULL OR domain = 'Unknown' OR id NOT IN (SELECT DISTINCT job_id FROM job_terms WHERE kind='skill')"
        
        rows = conn.execute(sql).fetchall()
        if not rows:
            return 0

        if force_all:
            conn.execute("DELETE FROM job_terms WHERE kind='skill'")

        job_updates = []
        term_inserts = []
        for r in rows:
            jid, title, loc, exp, desc, ind, ev = r
            combined_text = f"{desc or ''} {ev or ''}".strip()
            res = extract_terms(title, loc, exp, combined_text, ind or "")
            job_updates.append((res["category"], res["domain"], jid))
            for kind, term in res["terms"]:
                if term:
                    term_inserts.append((jid, kind, term))

        conn.executemany("UPDATE jobs SET category=?, domain=? WHERE id=?", job_updates)
        conn.executemany("INSERT OR IGNORE INTO job_terms (job_id, kind, term) VALUES (?, ?, ?)", term_inserts)
        conn.commit()
        return len(rows)
