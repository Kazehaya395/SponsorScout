"""Domain and Category taxonomy loader and pattern matchers."""

import csv
import json
import logging
import os
import re
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

_MODULE_DIR = Path(__file__).resolve().parent

# Support multiple locations for bundled data files (dev repo, pyinstaller, user data)
def _find_data_file(filename: str) -> Path:
    candidates = [
        _MODULE_DIR / filename,
        Path(getattr(sys, "_MEIPASS", "")) / "sponsorscout" / "insights" / filename,
        Path(getattr(sys, "_MEIPASS", "")) / filename,
        Path(os.getcwd()) / "sponsorscout" / "insights" / filename,
    ]
    for p in candidates:
        if p and p.exists():
            return p
    return _MODULE_DIR / filename

_CATEGORIES: dict[str, list[str]] = {}
_CATEGORY_REGEXES: list[tuple[str, re.Pattern]] = []
_DOMAINS: dict[str, list[str]] = {}
_DOMAIN_MAP: dict[str, str] = {}
_SKILLS: list[dict] = []


def _load_data():
    global _CATEGORIES, _CATEGORY_REGEXES, _DOMAINS, _DOMAIN_MAP, _SKILLS
    if _SKILLS:
        return

    # Load categories
    cat_file = _find_data_file("categories.json")
    if cat_file.exists():
        try:
            with open(cat_file, "r", encoding="utf-8") as f:
                _CATEGORIES = json.load(f)
            for cat, keywords in _CATEGORIES.items():
                pattern = r"\b(?:" + "|".join(re.escape(k) for k in keywords) + r")\b"
                _CATEGORY_REGEXES.append((cat, re.compile(pattern, re.I)))
        except Exception as e:
            logger.warning("Could not load categories.json: %s", e)

    # Load domains
    dom_file = _find_data_file("domains.json")
    if dom_file.exists():
        try:
            with open(dom_file, "r", encoding="utf-8") as f:
                _DOMAINS = json.load(f)
            for dom, industries in _DOMAINS.items():
                for ind in industries:
                    _DOMAIN_MAP[ind.casefold()] = dom
        except Exception as e:
            logger.warning("Could not load domains.json: %s", e)

    # Load skills
    skill_file = _find_data_file("skills_dictionary.csv")
    if skill_file.exists():
        try:
            with open(skill_file, "r", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    flags = 0 if row.get("case_sensitive", "").strip().lower() == "true" else re.I
                    try:
                        pat = re.compile(row["pattern"], flags)
                        _SKILLS.append({
                            "term": row["term"],
                            "group": row.get("group", "General"),
                            "regex": pat,
                        })
                    except Exception:
                        continue
        except Exception as e:
            logger.warning("Could not load skills_dictionary.csv: %s", e)


def classify_category(title: str, text: str = "") -> str:
    """Classify a job's category from title, falling back to description."""
    _load_data()
    title = (title or "").strip()
    for cat, reg in _CATEGORY_REGEXES:
        if reg.search(title):
            return cat
    if text:
        for cat, reg in _CATEGORY_REGEXES:
            if reg.search(text):
                return cat
    return "Other"


def classify_domain(industry: str) -> str:
    """Map a seed industry string to an official Employer Domain."""
    _load_data()
    if not industry:
        return "Unknown"
    norm = industry.strip().casefold()
    if norm in _DOMAIN_MAP:
        return _DOMAIN_MAP[norm]
    # Fuzzy substring fallback
    for ind, dom in _DOMAIN_MAP.items():
        if ind in norm or norm in ind:
            return dom
    return "Unknown"


def extract_skills(text: str) -> list[str]:
    """Extract matching technical and soft skills from arbitrary text (e.g. JD snippet)."""
    _load_data()
    if not text:
        return []
    found = []
    for skill in _SKILLS:
        if skill["regex"].search(text):
            found.append(skill["term"])
    return found


_SOFT_SKILL_GROUPS = {
    "Soft Skills",
    "Professional Skills & Work Methods",
    "Project, Product & Business Operations",
    "HR, Recruitment & People Operations",
}


def is_soft_skill(group_name: str, term_name: str = "") -> bool:
    return group_name in _SOFT_SKILL_GROUPS


def extract_terms(title: str, location: str, experience_level: str, text: str, industry: str) -> dict:
    """Extract all structured terms for the job_terms table and jobs columns."""
    _load_data()
    category = classify_category(title, text)
    domain = classify_domain(industry)
    combined = f"{title or ''} {text or ''}".strip()
    
    terms = []
    for item in _SKILLS:
        if item["regex"].search(combined):
            grp = item["group"]
            term_name = item["term"]
            if grp == "Location Targeting":
                kind = "location_target"
            elif grp in ("Work Arrangement & Mobility", "Job Portal / Source Targeting"):
                kind = "work_mode_target"
            else:
                kind = "soft_skill" if grp in _SOFT_SKILL_GROUPS else "technical_skill"
                terms.append(("skill", term_name))
            terms.append((kind, term_name))

    if location and location.lower() not in ("unknown", "not specified"):
        terms.append(("location", location.strip()))
    if experience_level and experience_level.lower() not in ("unknown", "?", ""):
        terms.append(("experience", experience_level.strip()))

    return {
        "category": category,
        "domain": domain,
        "terms": terms,
    }

extract_skills_from_text = extract_skills
