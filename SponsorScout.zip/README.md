# SponsorScout

[🇬🇧 English](#-english) · [🇮🇹 Italiano](#-italiano)

Find jobs that actually sponsor visas — scanned from official sources, stored
on your own computer.

---


# 🇬🇧 English

## 📖 Contents

- [Download](#-download)
- [Screenshots](#-screenshots)
- [What It Does](#-what-it-does)
- [Quick Start](#-quick-start)
- [The Eight Tabs](#-the-eight-tabs)
- [Scanning](#-scanning)
- [Verification and Fix Register](#verification-and-fix-register)
- [Where Your Data Lives](#-where-your-data-lives)
- [Troubleshooting](#-troubleshooting)
- [Building From Source](#-building-from-source)
- [Requirements](#-requirements)
- [License](#-license)

---

## 📥 Download

Installers are on the [GitHub Releases page](https://github.com/Kazehaya395/SponsorScout/releases):

| Platform | File |
|----------|------|
| Windows 10 / 11 | `sponsorscout-<version>-setup.exe` |
| Linux (Debian / Ubuntu / Mint) | `sponsorscout_<version>_<arch>.deb` |
| Linux (Fedora / RHEL / openSUSE) | `sponsorscout-<version>-1.<arch>.rpm` |

`<arch>` is your machine's architecture (`amd64` on most desktops, `arm64` on
Raspberry Pi / Graviton). Pick the file for your platform. The app and its
browser are bundled, so no Python is needed.

Installing the Linux packages:

```bash
# Debian / Ubuntu / Mint
sudo apt install ./sponsorscout_<version>_<arch>.deb

# Fedora / RHEL / openSUSE
sudo dnf install ./sponsorscout-<version>-1.<arch>.rpm   # or: sudo zypper install ...
```

Both packages install to `/opt/sponsorscout` and add a launcher plus a desktop
entry; the bundled Chromium is used automatically.

---

## 📸 Screenshots

**Dashboard — KPIs, top sponsoring companies and jobs by country**
<img src="assets/main_dashboard.png" alt="SponsorScout Dashboard tab: total companies, verified, sponsored and remote jobs, top companies by sponsorship, jobs by country" width="860">

**Search — filters, tri-state sponsorship columns and pagination**
<img src="assets/job_search_table.png" alt="SponsorScout Search tab: title, company, location and experience filters, Sponsor, Blue Card, Reloc and Regex toggles, result counter with pagination and a sortable job table" width="860">

**Tools — scan control, live progress log, run history and data quality**
<img src="assets/scanning_tool.png" alt="SponsorScout Tools tab: Scan Now and Custom Scan, progress bar with the live scan log, scan history table with log download, data-quality and freshness actions" width="860">

**Data Management — editable ATS and career seed files**
<img src="assets/backend_data_management.png" alt="SponsorScout Data Management tab: ATS portals and career portals seed editor with Add, Edit, Delete, Save to CSV, Reload and Reset to bundled defaults" width="860">

**Custom Scan - Custom job search portals selection**
<img src="assets/custom_portal_selection.png" alt="SponsorScout Data Management tab: ATS portals and career portals seed editor with Add, Edit, Delete, Save to CSV, Reload and Reset to bundled defaults" width="860">

**AI Tailoring — job description, AI prompt, CV and cover letter, copied in one go**
<img src="assets/AI_tailoring_setup.png" alt="SponsorScout AI Tailoring tab: selected job and JD URL, editable job description, AI prompt, CV and cover letter boxes with Save buttons, and a Copy prompt + JD + CV + CL button" width="860">

**Assisted Ingestion — resolve bot-blocked portals and ingest jobs directly into the app**
<img src="assets/assisted_ingestion.png" alt="SponsorScout Assisted Ingestion: interactive browser window for human verification with automated pagination and direct database ingestion" width="860">

**Insights — category, skill, domain and sponsorship distributions**
<img src="assets/insights_dashboard.png" alt="SponsorScout Insights tab: category and in-demand skills charts, domain distribution and category sponsorship breakdown" width="860">

---

## ✨ What It Does

- **Scans official sources only** — 8 ATS job boards (Ashby, Greenhouse,
  Lever, SmartRecruiters, Personio, Recruitee, Workable, Workday) through their
  public APIs, plus company career pages with a headless browser when needed.
- **Classifies every job** — sponsorship, relocation support, remote type and
  EU Blue Card eligibility, detected from the job description.
- **Extracts the experience requirement** — the exact figure the ad states
  (`4+`, `3-5 years`, `6 months`), or the seniority level (`Senior`), read in
  English, German, Italian, Dutch, French, Spanish and Portuguese.
- **Keeps everything local** — one SQLite file on your computer. Nothing is
  uploaded.
- **Tracks applications** — Saved → Applied → Interview → Offer → Rejected.
- **Two languages** — English and Italian, switchable at any time.

---

## 🚀 Quick Start

1. Download and install the package for your platform.
2. Launch SponsorScout. On first start, accept the prompt to run an initial
   scan. Depending on how many companies are enabled it can take from minutes to hours.
3. Open **Search** to browse, and **Applications** to track what you apply to.

---

## 🗂 The Eight Tabs
### 1. Dashboard
Company totals, verified-sponsorship counts, scan actions (**Scan Now**,
**Custom Scan**) and per-company rescan; the entry point for every run.

<img src="assets/main_dashboard.png" alt="Dashboard tab: KPI cards, top companies by sponsorship and the scan action row" width="780">

### 2. Search
Every scanned vacancy with filters (country, title, sponsorship tri-state,
Blue Card, remote type); open the original ad or send the job to the AI
Prompt Kit.

<img src="assets/job_search_table.png" alt="Search tab: filter row, tri-state Sponsor and Blue Card filters and the results table" width="780">

### 3. Applications
Per-job application tracking (status, dates, notes) stored locally.

### 4. Tools
Scan control and history: progress, **Scan History** with the per-run log set
(the five CSVs), seed shortcuts and diagnostics.

<img src="assets/scanning_tool.png" alt="Tools tab: Scan Now and Custom Scan buttons, progress and Scan History" width="780">

### 5. Data Management
Edit the company lists that get scanned (**ATS portals** and **Career
portals**). Changes apply on the next scan; **Reset to bundled defaults**
restores the original lists.

<img src="assets/backend_data_management.png" alt="Data Management tab: ATS portals and career portals seed editor with Save to CSV, Reload and Reset actions" width="780">

### 6. AI Prompt Kit
Build one message for any AI chatbot: **Load JD** fills the job description
(or paste a link in **or JD URL**), then **Copy prompt + JD + CV + CL** copies
prompt, job description, CV and cover letter in full, in that order. Prompt,
CV and cover letter persist between sessions.

<img src="assets/AI_tailoring_setup.png" alt="AI Prompt Kit tab: job description, AI prompt, CV and cover letter boxes with Load JD and Copy buttons" width="780">

### 7. Insights
Aggregated visual market intelligence derived directly from scanned
vacancies: category & role and employer-industry donut charts with
click-to-cross-filter, in-demand technical and soft skill frequency lists
without arbitrary truncation, and a sponsorship-per-category table that keeps
Yes / No / Unknown distinct.

<img src="assets/insights_dashboard.png" alt="Insights tab: category and in-demand skills charts, domain distribution and category sponsorship breakdown" width="860">

### 8. Assisted Ingestion
Dedicated interactive browser environment for bot-guarded portals
(Cloudflare, PerimeterX, Datadome, "Press & Hold"): launch an interactive
Chromium window for any careers portal, clear the human verification once,
and SponsorScout takes over — automatic pagination across all result pages
and direct database ingestion, recorded with the same run logs as a regular
scan (see [Scanning](#-scanning)).

<img src="assets/assisted_ingestion.png" alt="Assisted Ingestion: interactive browser window for human verification with automated pagination and direct database ingestion" width="860">

---

## 🔍 Scanning

### Full scan
The default. **Scan Now** (or the Dashboard's **Rescan Companies**) scans every
seeded company, because a partial scan would silently hide jobs you did not ask
for.

### Custom scan
**Tools → Custom Scan** lets you choose:

- **Source types** — *ATS portals* (fast, API-based) and/or *Career portals*
  (slower, crawled with a browser).
- **Companies** — tick the ones you want; filter or bulk-select to move fast.

A custom scan runs the exact same pipeline as a full scan, so result quality is
identical — only the scope and duration change. Use it to re-scan companies you
just edited. Custom runs appear as `custom` in Scan History.

<img src="assets/custom_portal_selection.png" alt="Data Management tab: ATS portals and career portals seed editor with Save to CSV, Reload and Reset actions" width="780">

### What a scan does
1. **ATS boards** — companies with a known ATS are pulled through the official
   job-board API.
2. **Career pages** — every company is also crawled through its own career page,
   so career-page-only companies are never skipped. Long lists are read page by
   page, following "next page" and "show more" links. On the fast path a board
   is read to at most 12 pages (`SPONSORSCOUT_STATIC_MAX_PAGES`); the browser
   pass reads further.
3. **Category-link check** — a link that leads to a department or category
   listing instead of a real job ad (its page shows more job links and no
   apply button) is detected and dropped, so only actual postings reach the
   database.
4. **Detail pages** — each job is checked for location, sponsorship,
   relocation, Blue Card evidence and experience. Verdicts are only set from
   explicit evidence, and weaker sources never overwrite stronger ones.
5. Results are saved to the local database and appear immediately.

Progress shows live (`ATS 12/46`, `Career 88/162`). A company with no open
roles counts as done.

### Assisted ingestion and bot-guarded portals
When a portal answers with a bot wall (Cloudflare, PerimeterX, Datadome,
"Press & Hold"), the **Assisted Ingestion** tab opens an interactive Chromium
window: you clear the challenge once, the harvest takes over and pages the
board automatically.

- **The board's own hrefs lead.** Pagination follows the links the board
  renders (signed paging tokens included); synthesised URLs are only a
  fallback, because signed pagers accept nothing else.
- **A refused advance is not the end.** A paging step that re-serves the
  identical listing is retried with a different mechanism; only three refused
  advances on a *full* page may call it the end — and only after polite
  escalating cool-downs (15 s → 45 s → 90 s, at most three pauses per run) and
  up to four out-of-range probe loads per run.
- **Honest stop reasons.** Every stop names the last complete page and why:
  "no next-page control recognised on page N (last complete page M)", "board
  re-served the same listing after 3 paging attempts (last complete page M)",
  or "page cap reached". "Pages read" counts complete listing pages, never
  browser loads; retries stay visible as `loads`.
- **Politeness is never removed:** inter-load delays stay, and the cool-downs
  above are pure waiting. `max_pages` defaults to 60 per board.

### Run logs — same set as the regular workflow
Every assisted run writes the same five-CSV set a regular scan writes, UTF-8
with BOM: `{run}_career_jobs.csv`, `{run}_career_jobs_recruiter.csv`,
`{run}_career_jobs_quarantine.csv`, `{run}_career_jobs_errors.csv` and
`{run}_career_jobs_scan_log.csv`; the run is also recorded in the
`scan_runs`, `scan_log` and `scan_events` tables and appears in Scan History.

### What happens when you press Start
Seed sync (with a backup of the previous seed files) → the selected targets
only → a provider sniff **only for seeds whose adapter is unknown** (≤4 s,
result cached, walled boards cached as negatives) → a connectivity preflight
that probes **only this run's hosts**, in parallel, warn-only → the crawl.
A one-company scan no longer waits on unrelated hosts.

---

## 💾 Where Your Data Lives

| Platform | Location |
|----------|----------|
| Windows | `%APPDATA%\SponsorScout` |
| Linux | `~/.sponsorscout` |

Contains `sponsorscout.db` (jobs, companies, applications, scan history),
`seeds/` (your editable company lists), `locale.json` (language) and raw scan
logs under `scan_output/`.

Copy `sponsorscout.db` to back everything up. Override the location with the
`SPONSORSCOUT_DATA_DIR` (or `SPONSORSCOUT_DB_PATH`) environment variable.

### Uninstalling

The Windows installer, the Linux `.deb` and the Linux `.rpm` all remove
SponsorScout-owned user data when the app is uninstalled — the SQLite database,
editable seeds, language setting and scan logs. The default locations are
cleaned for the current Windows user and for local Linux user accounts. Custom
data paths are also removed when their `SPONSORSCOUT_DATA_DIR` /
`SPONSORSCOUT_DB_PATH` environment variables are available to the uninstaller.
Back up anything you want to keep before uninstalling. The shared Playwright
browser cache is not removed because other applications may use it.

On Linux the two packages behave identically; `apt remove sponsorscout` /
`dnf remove sponsorscout` does the same as the Windows uninstaller.

---

## 🧰 Troubleshooting

**The Dashboard looks empty after a scan.** Click **Refresh**. If still empty,
check the newest **Scan History** row — an `error` status, or failures in its
log, shows which companies returned nothing.

**"Playwright is required for DOM fallback" / "Chromium browser is not
available".** Career pages are crawled with Playwright, and installers bundle
both the library and Chromium. To see exactly what is wrong in an installed
build, run:

```bash
/opt/sponsorscout/SponsorScout --self-check --self-check-browser
"C:\Program Files\SponsorScout\SponsorScout.exe" --self-check --self-check-browser
```

It reports whether `playwright` imports (including *why* it fails, e.g. a
missing `greenlet`), where Playwright looks for browsers, and whether the
bundled Chromium launches — without opening the app. Builds run this
automatically and refuse to package a broken bundle. From source, run
`python -m playwright install chromium`.

**SponsorScout will not download a browser by itself.** If Chromium is missing
the app logs a warning and keeps working, but JS-rendered career pages return 0
jobs. Install it once with `python -m playwright install chromium`. To restore
the old automatic behaviour set `SPONSORSCOUT_AUTO_INSTALL_BROWSERS=1` — it is
off by default because a ~130 MB download can block the scan for minutes.
Installed builds are unaffected: the browser ships inside the `.exe`, `.deb`
and `.rpm`.

**The scan stops with "Seed validation failed".** One invalid row in a career
seed stops the whole career phase, so no company in that file is scanned. The
message names the line, the company and the bad field, for example
`invalid source_type 'not found'`. Open **Data Management**, correct that row,
and run the scan again.

**Some companies returned no jobs.** They may have no open roles (`EMPTY` in
the log), or they may temporarily block automated access — try again later.
Nothing is dropped silently.

**The scan is slow.** The detail-page pass is the slow part, and it is bounded:
SponsorScout sizes its browser pool from your CPU/RAM, runs at below-normal
priority, and blocks images/fonts/media while crawling. The Dashboard stays
usable. You do not have to wait it out — press **Pause** to suspend the scan
where it is (nothing is lost, browsers just wait) and click the same button
again to continue instantly. **Stop** ends the run and keeps everything found,
and **Resume** later continues the unfinished companies, even after restarting
the app.

**A career portal is blocked by bot protection.** Some career sites show a bot-check page (for example PerimeterX "Press & Hold") to automated tools. To keep full-seed scans fast and unattended, SponsorScout logs these blocks without halting the main scan. When the scan finishes, it lists the affected portals and lets you choose:
- **In-App Assisted Ingest:** Launches a focused, visible browser session where you complete the 5-second human verification. Once cleared, SponsorScout automatically navigates all pages, extracts the job postings, and ingests them directly into your database so they appear in the **Search** tab.
- **Open in External Browser:** Opens the listing URL in your standard desktop browser for manual browsing.

**A job shows `?`.** `?` means *unknown*, never *no*. The ad had no explicit
evidence, so SponsorScout does not guess. Unknown jobs are never removed.

**Can I scan only some companies?** Yes — **Tools → Custom Scan**. Same
quality, only the scope changes.

**How do I search with a regular expression?** Tick **Regex** in **Search** and
type a pattern such as `(backend|platform).*engineer`. Case-insensitive; an
invalid pattern warns and falls back to a normal search.

**Does anything leave my computer?** No. The only outbound traffic is fetching
the job listings you asked for.

---

## 🏗 Building From Source

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt   # runtime + pyinstaller (used by the build scripts)
pip install -e ".[dev]"          # pytest, for the test suite
python -m playwright install chromium
```

`requirements.txt` is what the build scripts (`build_exe.ps1`, `build_deb.sh`,
`build_rpm.sh`) consume, so it must keep `pyinstaller`. The `.[dev]` extra adds
`pytest` for the suite; `pip install -e .` alone is enough if you only want to
run the app.

If you skip `playwright install chromium`, the app still starts but
JS-rendered career pages return 0 jobs. It will **not** download ~130 MB on its
own; set `SPONSORSCOUT_AUTO_INSTALL_BROWSERS=1` if you want that behaviour back.

**Windows installer:**
```powershell
.\build_exe.ps1               # -> dist\sponsorscout-<version>-setup.exe
```
(requires Inno Setup 6/7; bundles Playwright Chromium)

**Linux package (Debian / Ubuntu):**
```bash
./build_deb.sh                # -> dist/sponsorscout_<version>_<arch>.deb
```
Run it as your normal user: **do not use `sudo`**. The script creates an
isolated build environment in `.build/deb-venv`, so it never modifies the
system Python. If Python's venv module is missing, install it once with
`sudo apt install python3-venv`, then run `./build_deb.sh` again.
Packaging the ~1.4 GB payload (PySide6 + bundled Chromium) is the slow step and
prints how long it took; the `.deb` only appears in `dist/` once it is complete.
For a much faster build that requires dpkg >= 1.21.18 to install, use
`DEB_COMPRESSION=zstd ./build_deb.sh`.
Building from a Windows drive mounted in WSL (`/mnt/c/...` and friends) is not
recommended: those filesystems cannot store Unix permissions, so the build
detects it and stages the package in `/tmp`. For the fastest and most
reliable build, copy the project to a Linux filesystem such as `~/sponsorscout`.

**Linux package (Fedora / RHEL / openSUSE — RPM):**
```bash
./build_rpm.sh               # -> dist/sponsorscout-<version>-1.<arch>.rpm
```
Same rules as the `.deb`: run it as your normal user (**do not use `sudo`**)
and let it create the isolated `.build/rpm-venv`. Requires `rpmbuild`
(`sudo dnf install rpm-build` on Fedora/RHEL, `sudo apt install rpm` on
Debian/Ubuntu/WSL, `sudo zypper install rpm-build` on openSUSE). It bundles
Playwright Chromium, smoke-tests the binary and never strips the bundled
C-extensions — exactly like `build_deb.sh`. The payload compressor is probed
on your machine (fast xz by default); for a smaller package where every
target has rpm >= 4.14, use `RPM_COMPRESSION=zstd ./build_rpm.sh`. Like the
other two scripts it leaves `dist/` alone apart from its own output, so the
`.exe`, `.deb` and `.rpm` can be built side by side.

**Tests:**
```bash
python -m pytest sponsorscout/tests
```

---

---

## Verification and Fix Register
- **Suite:** `python -m pytest sponsorscout/tests -q --continue-on-collection-errors`
  → **681 passed / 12 failed / 4 skipped**; the 12 failures and 4 skips are the
  documented pre-existing set (baseline before this engagement: 560/15/6).
- **Pins:** every production fix ships with a regression pin under
  `sponsorscout/tests/` — the 2026-10-22 suites carry 103 harvest-consistency
  pins, 9 assisted-completeness pins and 4 tick-indicator pins.
- **Gates:** `tests/test_run20261016_fixes.py` (61 PASS / 0 FAIL),
  `tests/test_run20261016B_fixes.py` (62 PASS / 0 FAIL) and
  `tools/check_readme_anchors.py` (every in-page link resolves).
- **Live verification:** `live_verify/synth_board.py` +
  `live_verify/live_verify_synth.py` (shipped alongside this repo in the fixes
  archive) replay a synthetic windowed-pager board with signed hrefs through an
  eight-phase harness — baseline, window slide, mid-run challenge cleared and
  uncleared, false end + CSV parity, clamp at end, soft denial, and a
  six-refusal rate-limit window; `live_verify/live_verify_deep.py` proves a
  27-page board end to end.
- **Fix register:** F-01…F-40 and delivery revisions 1–13 are recorded in
  `FIXES_MANIFEST.md` (shipped with the fixes archive); highlights: TLS
  verification restored, walker fractions, low-memory profile, SmartRecruiters
  and Elior adapters, replica schema, tick indicator (rev 3), assisted
  harvest consistency and CSV parity (F-27…F-36), false-end probes and honest
  counters (F-33…F-35c), cool-downs and denied-href retries (F-37…F-38),
  run-row timestamps (F-39), scoped startup (F-40).

## 📋 Requirements

- Python 3.10 or newer (to run from source; installers need nothing)
- Runtime: **PySide6**, **requests**, **playwright** (`requirements.txt`)
- Playwright Chromium: `python -m playwright install chromium`
- Dev/test: **pytest**, **pyinstaller** (`pip install ".[dev]"`)
- Linux packaging: `python3`, `python3-venv`, and `dpkg` (`sudo apt install python3-venv`); `rpmbuild` for the `.rpm` (`sudo dnf install rpm-build` / `sudo apt install rpm`)
- Optional: `SPONSORSCOUT_AUTO_INSTALL_BROWSERS=1` lets the app download Chromium itself when it is missing (off by default)

---

## 📄 License

MIT — see [LICENSE](LICENSE).

---


# 🇮🇹 Italiano

## 📖 Indice

- [Scarica](#-scarica)
- [Schermate](#-schermate)
- [Cosa Fa](#-cosa-fa)
- [Avvio Rapido](#-avvio-rapido)
- [Le Otto Schede](#-le-otto-schede)
- [Scansione](#-scansione)
- [Verifica e registro fix](#verifica-e-registro-fix)
- [Dove Sono i Tuoi Dati](#-dove-sono-i-tuoi-dati)
- [Risoluzione Problemi](#-risoluzione-problemi)
- [Compilare dai Sorgenti](#-compilare-dai-sorgenti)
- [Requisiti](#-requisiti)
- [Licenza](#-licenza)

---

## 📥 Scarica

Gli installer sono nella [pagina GitHub Releases](https://github.com/Kazehaya395/SponsorScout/releases):

| Piattaforma | File |
|-------------|------|
| Windows 10 / 11 | `sponsorscout-<versione>-setup.exe` |
| Linux (Debian / Ubuntu / Mint) | `sponsorscout_<versione>_<arch>.deb` |
| Linux (Fedora / RHEL / openSUSE) | `sponsorscout-<versione>-1.<arch>.rpm` |

`<arch>` è l'architettura della tua macchina (`amd64` sulla maggior parte dei
desktop, `arm64` su Raspberry Pi / Graviton). Scegli il file per la tua
piattaforma. L'app e il browser sono inclusi, quindi non serve Python.

Installare i pacchetti Linux:

```bash
# Debian / Ubuntu / Mint
sudo apt install ./sponsorscout_<versione>_<arch>.deb

# Fedora / RHEL / openSUSE
sudo dnf install ./sponsorscout-<versione>-1.<arch>.rpm   # oppure: sudo zypper install ...
```

Entrambi i pacchetti installano in `/opt/sponsorscout` e aggiungono un launcher
più una voce nel menu applicazioni; il Chromium incluso viene usato
automaticamente.

---

## 📸 Schermate

**Pannello — KPI, migliori aziende per sponsorizzazione e lavori per paese**
<img src="assets/main_dashboard.png" alt="Scheda Pannello di SponsorScout: totale aziende, lavori verificati, sponsorizzati e remoti, migliori aziende per sponsorizzazione, lavori per paese" width="860">

**Cerca — filtri, colonne tri-stato e paginazione**
<img src="assets/job_search_table.png" alt="Scheda Cerca di SponsorScout: filtri per posizione, azienda, località ed esperienza, opzioni Sponsor, Carta Blu, Trasferimento e Regex, contatore risultati con paginazione e tabella ordinabile" width="860">

**Strumenti — controllo scansione, log live, cronologia e qualità dati**
<img src="assets/scanning_tool.png" alt="Scheda Strumenti di SponsorScout: Scansiona Ora e Scansione Personalizzata, barra di avanzamento con log della scansione, cronologia con download dei log, azioni di qualità dati e verifica aggiornamento" width="860">

**Gestione Dati — file seed ATS e Career modificabili**
<img src="assets/backend_data_management.png" alt="Scheda Gestione Dati di SponsorScout: editor dei file seed Portali ATS e Portali Career con Aggiungi, Modifica, Elimina, Salva su CSV, Ricarica e Ripristina predefiniti" width="860">

**Scansione personalizzata - Selezione dei portali di ricerca lavoro personalizzati**
<img src="assets/custom_portal_selection.png" alt="SponsorScout Data Management tab: ATS portals and career portals seed editor with Add, Edit, Delete, Save to CSV, Reload and Reset to bundled defaults" width="860">

**Adattamento IA — descrizione del lavoro, prompt IA, CV e lettera di presentazione in una sola copia**
<img src="assets/AI_tailoring_setup.png" alt="Scheda Adattamento IA di SponsorScout: lavoro selezionato e URL JD, descrizione del lavoro modificabile, riquadri prompt IA, CV e lettera di presentazione con pulsanti Salva, e pulsante Copia prompt + JD + CV + CL" width="860">

---


**Acquisizione assistita — risolvi i portali bloccati e importa le offerte direttamente nell'app**
<img src="assets/assisted_ingestion.png" alt="Acquisizione assistita di SponsorScout: finestra browser interattiva per la verifica umana con paginazione automatica e inserimento diretto nel database" width="860">

**Approfondimenti — distribuzioni per categoria, competenze, settore e sponsorizzazione**
<img src="assets/insights_dashboard.png" alt="Scheda Approfondimenti di SponsorScout: grafici di categorie e competenze più richieste, distribuzione settoriale e ripartizione sponsorizzazioni per categoria" width="860">

## ✨ Cosa Fa

- **Scansiona solo fonti ufficiali** — 8 bacheche ATS (Ashby, Greenhouse,
  Lever, SmartRecruiters, Personio, Recruitee, Workable, Workday) tramite le
  loro API pubbliche, più le pagine carriera delle aziende con un browser
  headless quando necessario.
- **Classifica ogni lavoro** — sponsorizzazione, trasferimento, tipo di lavoro
  remoto e idoneità alla Carta Blu UE, rilevati dalla descrizione.
- **Estrae l'esperienza richiesta** — la cifra esatta indicata
  (`4+`, `3-5 anni`, `6 mesi`), oppure il livello di seniority (`Senior`),
  riconosciuta in inglese, tedesco, italiano, olandese, francese, spagnolo e
  portoghese.
- **Mantiene tutto in locale** — un unico file SQLite sul tuo computer. Nulla
  viene caricato online.
- **Gestisce le candidature** — Salvata → Inviata → Colloquio → Offerta →
  Rifiutata.
- **Due lingue** — Italiano e Inglese, selezionabili in qualsiasi momento.

---

## 🚀 Avvio Rapido

1. Scarica e installa il pacchetto per la tua piattaforma.
2. Avvia SponsorScout. Al primo avvio accetta la richiesta di eseguire la
   scansione iniziale. A seconda di quante aziende sono attive può richiedere da pochi minuti a ore.
3. Apri **Cerca** per sfoglare e **Candidature** per gestire le candidature.

---

## 🗂 Le Otto Schede
### 1. Pannello
Totali aziende, conteggi di sponsorizzazione verificata, azioni di scansione
(**Scansiona Ora**, **Scansione Personalizzata**) e riscansione per azienda;
il punto di ingresso di ogni esecuzione.

<img src="assets/main_dashboard.png" alt="Scheda Pannello: card KPI, migliori aziende per sponsorizzazione e riga azioni di scansione" width="780">

### 2. Cerca
Tutte le offerte scansionate con filtri (paese, titolo, sponsorizzazione a tre
stati, Blue Card, modalità remota); apri l'annuncio originale o invia l'offerta
al Kit Prompt AI.

<img src="assets/job_search_table.png" alt="Scheda Cerca: riga filtri, filtri Sponsor e Blue Card a tre stati e tabella risultati" width="780">

### 3. Candidature
Tracciamento delle candidature per offerta (stato, date, note) salvato in
locale.

### 4. Strumenti
Controllo e cronologia scansioni: avanzamento, **Cronologia Scansioni** con il
set di log per esecuzione (i cinque CSV), scorciatoie ai seed e diagnostica.

<img src="assets/scanning_tool.png" alt="Scheda Strumenti: pulsanti Scansiona Ora e Scansione Personalizzata, avanzamento e Cronologia Scansioni" width="780">

### 5. Gestione Dati
Modifica gli elenchi di aziende da scansionare (**Portali ATS** e **Portali
Career**). Le modifiche valgono dalla scansione successiva; **Ripristina
predefiniti** riporta le liste originali.

<img src="assets/backend_data_management.png" alt="Scheda Gestione Dati: editor dei seed Portali ATS e Portali Career con Salva su CSV, Ricarica e Ripristina" width="780">

### 6. Kit Prompt AI
Costruisci un unico messaggio per qualsiasi chatbot: **Load JD** compila la
descrizione del lavoro (o incolla un link in **or JD URL**), poi **Copy prompt
+ JD + CV + CL** copia prompt, descrizione, CV e lettera di presentazione per
intero, in quest'ordine. Prompt, CV e lettera persistono tra le sessioni.

<img src="assets/AI_tailoring_setup.png" alt="Scheda Kit Prompt AI: caselle descrizione lavoro, prompt AI, CV e lettera di presentazione con pulsanti Load JD e Copy" width="780">

### 7. Approfondimenti
Intelligence di mercato aggregata, derivata direttamente dalle offerte
scansionate: grafici a ciambella per categoria/ruolo e settore industriale con
cross-filter al clic, elenchi di frequenza delle competenze tecniche e soft
senza troncamenti arbitrari e tabella di sponsorizzazione per categoria che
mantiene distinti Sì / No / Sconosciuto.

<img src="assets/insights_dashboard.png" alt="Scheda Approfondimenti: grafici di categorie e competenze più richieste, distribuzione settoriale e ripartizione sponsorizzazioni per categoria" width="860">

### 8. Acquisizione Assistita
Ambiente browser interattivo dedicato ai portali con protezione bot
(Cloudflare, PerimeterX, Datadome, "Press & Hold"): avvia una finestra
Chromium interattiva per qualsiasi portale career, supera una sola volta la
verifica umana e SponsorScout prende il comando — paginazione automatica su
tutte le pagine dei risultati e inserimento diretto nel database, registrato
con gli stessi log di una scansione regolare (vedi [Scansione](#-scansione)).

<img src="assets/assisted_ingestion.png" alt="Acquisizione Assistita: finestra browser interattiva per la verifica umana con paginazione automatica e inserimento diretto nel database" width="860">

---

## 🔍 Scansione

### Scansione completa
Quella predefinita. **Scansiona Ora** (o **Riscansiona Aziende** nel Pannello)
scansiona ogni azienda negli elenchi, perché una scansione parziale
nasconderebbe in silenzio dei lavori che non hai chiesto.

### Scansione personalizzata
**Strumenti → Scansione Personalizzata** ti lascia scegliere:

- **Tipi di fonte** — *Portali ATS* (veloci, via API) e/o *Portali Career*
  (più lenti, esplorati con un browser).
- **Aziende** — spunta quelle che ti servono; usa il filtro o la selezione
  rapida per spostarti in fretta.

Una scansione personalizzata usa esattamente la stessa pipeline di una scansione
completa, quindi la qualità dei risultati è identica: cambiano solo ambito
e durata. Usala per riscanare le aziende che hai appena modificato. Le
esecuzioni personalizzate compaiono come `custom` nella Cronologia Scansioni.

<img src="assets/custom_portal_selection.png" alt="Data Management tab: ATS portals and career portals seed editor with Save to CSV, Reload and Reset actions" width="780">

### Cosa fa una scansione
1. **Bacheche ATS** — le aziende con un ATS noto vengono interrogate tramite
   l'API ufficiale della bacheca.
2. **Pagine carriera** — ogni azienda viene esplorata anche sulla propria
   pagina carriera, quindi le aziende con la sola pagina carriera non vengono
   saltate. Le liste lunghe vengono lette pagina per pagina, seguendo i link
   "pagina successiva" e "mostra altri". Nel percorso rapido una bacheca viene
   letta al massimo per 12 pagine (`SPONSORSCOUT_STATIC_MAX_PAGES`); il
   passaggio con il browser va oltre.
3. **Controllo link di categoria** — un link che porta a un elenco di reparto
   o categoria invece che a un vero annuncio (la pagina mostra altri link a
   lavori e nessun pulsante di candidatura) viene riconosciuto e scartato,
   così nel database entrano solo gli annunci reali.
4. **Pagine di dettaglio** — ogni lavoro viene verificato per località,
   sponsorizzazione, trasferimento, Carta Blu UE ed esperienza. I verdetti
   vengono impostati solo con evidenze esplicite e le fonti più deboli non
   sovrascrivono mai quelle più forti.
5. I risultati vengono salvati nel database locale e compaiono subito.

L'avanzamento è live (`ATS 12/46`, `Carriere 88/162`). Un'azienda senza
posizioni aperte conta come completata.

### Acquisizione assistita e portali con protezione bot
Quando un portale risponde con un muro anti-bot (Cloudflare, PerimeterX,
Datadome, "Press & Hold"), la scheda **Acquisizione Assistita** apre una
finestra Chromium interattiva: superi la verifica una volta e la raccolta
prende il comando, paginando il portale automaticamente.

- **Comandano gli href del portale.** La paginazione segue i link che il
  portale stesso renderizza (token di paginazione firmati inclusi); gli URL
  sintetizzati sono solo un ripiego, perché i pager firmati accettano solo i
  propri href.
- **Un avance rifiutato non è la fine.** Un passo di paginazione che
  ri-serve lo stesso elenco viene ritentato con un altro meccanismo; solo tre
  avance rifiutati su una pagina *piena* possono dichiarare la fine — e solo
  dopo cool-down educati e crescenti (15 s → 45 s → 90 s, al massimo tre pause
  per esecuzione) e al più quattro probe fuori intervallo per esecuzione.
- **Motivi di stop onesti.** Ogni stop indica l'ultima pagina completa e il
  motivo: "no next-page control recognised on page N (last complete page M)",
  "board re-served the same listing after 3 paging attempts (last complete
  page M)" oppure "page cap reached". "Pages read" conta le pagine di elenco
  complete, mai i caricamenti del browser; i tentativi restano visibili come
  `loads`.
- **La cortesia non si rimuove:** i ritardi fra i caricamenti restano, e i
  cool-down qui sopra sono pura attesa. `max_pages` è 60 per portale.

### Log di esecuzione — lo stesso set del flusso regolare
Ogni esecuzione assistita scrive lo stesso set di cinque CSV di una scansione
regolare, UTF-8 con BOM: `{run}_career_jobs.csv`, `{run}_career_jobs_recruiter.csv`,
`{run}_career_jobs_quarantine.csv`, `{run}_career_jobs_errors.csv` e
`{run}_career_jobs_scan_log.csv`; l'esecuzione è registrata anche nelle
tabelle `scan_runs`, `scan_log` e `scan_events` e compare nella Cronologia
Scansioni.

### Cosa succede quando premi Start
Sincronizzazione seed (con backup dei file precedenti) → solo i target
selezionati → sniff del provider **soltanto per i seed con adapter sconosciuto**
(≤4 s, risultato in cache; i portali con muro memorizzati come negativi) →
preflight di connettività che prova **solo gli host di questa esecuzione**, in
parallelo e senza bloccare → la scansione. Una scansione da un'azienda non
aspetta più su host non coinvolti.

---

## 💾 Dove Sono i Tuoi Dati

| Piattaforma | Posizione |
|-------------|-----------|
| Windows | `%APPDATA%\SponsorScout` |
| Linux | `~/.sponsorscout` |

Contiene `sponsorscout.db` (lavori, aziende, candidature, cronologia scansioni),
`seeds/` (i tuoi elenchi modificabili), `locale.json` (lingua) e i log grezzi
in `scan_output/`.

Copia `sponsorscout.db` per salvare tutto. Puoi cambiare la posizione con la
variabile d'ambiente `SPONSORSCOUT_DATA_DIR` (o `SPONSORSCOUT_DB_PATH`).

### Disinstallazione

L'installer Windows, il pacchetto Linux `.deb` e il pacchetto Linux `.rpm`
rimuovono durante la disinstallazione tutti i dati locali di SponsorScout:
database SQLite, elenchi modificabili, lingua e log delle scansioni. Vengono
pulite le posizioni predefinite dell'utente Windows e degli account Linux
locali. Vengono rimosse anche le posizioni personalizzate se le variabili
`SPONSORSCOUT_DATA_DIR` / `SPONSORSCOUT_DB_PATH` sono disponibili al programma
di disinstallazione. Fai una copia di cio che vuoi conservare prima di
disinstallare. La cache condivisa dei browser Playwright non viene rimossa,
perche potrebbe servire ad altre applicazioni.

Su Linux i due pacchetti si comportano allo stesso modo; `apt remove
sponsorscout` / `dnf remove sponsorscout` equivalgono alla disinstallazione
Windows.

---

## 🧰 Risoluzione Problemi

**Il Pannello sembra vuoto dopo una scansione.** Clicca **Aggiorna**. Se è
ancora vuoto, controlla l'ultima riga della **Cronologia Scansioni**: uno stato
`error`, o errori nel registro, indicano quali aziende non hanno restituito
lavori.

**"Playwright is required for DOM fallback" / "Chromium browser is not
available".** Le pagine carriera vengono esplorate con Playwright, e gli
installer includono sia la libreria sia Chromium. Per vedere esattamente cosa
non funziona in una build installata, esegui:

```bash
/opt/sponsorscout/SponsorScout --self-check --self-check-browser
"C:\Program Files\SponsorScout\SponsorScout.exe" --self-check --self-check-browser
```

Riporta se `playwright` si importa (incluso il *motivo* di un eventuale
errore, ad esempio `greenlet` mancante), dove Playwright cerca i browser e se
il Chromium incluso si avvia — senza aprire l'app. Le build eseguono questo
controllo automaticamente e rifiutano di pacchettizzare un bundle rotto. Da
codice sorgente, esegui `python -m playwright install chromium`.

**SponsorScout non scarica un browser da solo.** Se Chromium manca, l'app
scrive un avviso e continua a funzionare, ma le pagine carriera renderizzate via
JavaScript restituiscono 0 lavori. Installalo una volta con
`python -m playwright install chromium`. Per riattivare il comportamento
automatico di prima imposta `SPONSORSCOUT_AUTO_INSTALL_BROWSERS=1`: e disattivato
perche un download di ~130 MB puo bloccare la scansione per minuti. Le build
installate non ne risentono: il browser e incluso dentro `.exe`, `.deb` e
`.rpm`.

**La scansione si interrompe con "Seed validation failed".** Una riga non valida in
un seed career blocca l'intera fase career, quindi nessuna azienda di quel file
viene scansionata. Il messaggio indica riga, azienda e campo errato, per esempio
`invalid source_type 'not found'`. Apri **Gestione Dati**, correggi quella riga
e ripeti la scansione.

**Alcune aziende non hanno restituito lavori.** Potrebbero non avere posizioni
aperte (`EMPTY` nel log) oppure bloccare temporaneamente l'accesso automatico:
riprova più tardi. Nulla viene perso in silenzio.

**La scansione è lenta.** La fase di dettaglio è la più lenta ed è limitata:
SponsorScout dimensiona i browser in base a CPU/RAM, gira con priorità
inferiore al normale e blocca immagini/font/media. Il Pannello resta
utilizzabile. Non devi aspettare tutto: premi **Pausa** per sospendere la
scansione dove si trova (nulla va perso, i browser attendono) e clicca di nuovo
lo stesso pulsante per continuare subito. **Ferma** termina l'esecuzione
mantenendo tutto ciò che è stato trovato, e **Riprendi** più tardi continua le
aziende non finite, anche dopo aver riavviato l'app.

**Un portale di carriera è bloccato dalla protezione anti-bot.** Alcuni siti di carriera mostrano agli strumenti automatici una pagina di verifica anti-bot (ad esempio PerimeterX "Press & Hold"). Per mantenere le scansioni rapide e automatiche, SponsorScout registra questi blocchi senza interrompere la scansione principale. Al termine della scansione, elenca i portali interessati e ti consente di scegliere:
- **Acquisizione assistita integrata:** Apre una sessione browser visibile in cui completi la verifica umana di 5 secondi. Una volta superata, SponsorScout scorre automaticamente tutte le pagine, estrae le offerte e le inserisce direttamente nel database, mostrandole nella scheda **Cerca**.
- **Apri nel browser esterno:** Apre l'URL del portale nel browser predefinito per una navigazione manuale.

**Un lavoro mostra `?`.** `?` significa *sconosciuto*, mai *no*. L'annuncio non
conteneva evidenze esplicite, quindi SponsorScout non ipotizza nulla. I lavori
sconosciuti non vengono mai rimossi.

**Posso scansionare solo alcune aziende?** Sì — **Strumenti → Scansione
Personalizzata**. Stessa qualità, cambia solo l'ambito.

**Come si cerca con un'espressione regolare?** Spunta **Regex** in **Cerca** e
digita un pattern come `(backend|platform).*engineer`. Non distingue
maiuscole/minuscole; un pattern non valido mostra un avviso e ripiega su una
ricerca normale.

**Qualcosa esce dal mio computer?** No. L'unico traffico in uscita sono gli
annunci lavori che hai chiesto di scaricare.

---

## 🏗 Compilare dai Sorgenti

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt   # runtime + pyinstaller (usati dagli script di build)
pip install -e ".[dev]"          # pytest, per la suite di test
python -m playwright install chromium
```

Se salti `playwright install chromium` l'app parte comunque, ma le pagine
carriere renderizzate via JavaScript restituiscono 0 lavori. Non scarica da solo
~130 MB; imposta `SPONSORSCOUT_AUTO_INSTALL_BROWSERS=1` per riattivarlo.

**Installer Windows:**
```powershell
.\build_exe.ps1               # -> dist\sponsorscout-<versione>-setup.exe
```
(richiede Inno Setup 6/7; include Playwright Chromium)

**Pacchetto Linux (Debian / Ubuntu):**
```bash
./build_deb.sh                # -> dist/sponsorscout_<versione>_<arch>.deb
```
Esegui lo script come utente normale: **non usare `sudo`**. Lo script crea un
ambiente di compilazione isolato in `.build/deb-venv`, quindi non modifica mai
Python di sistema. Se manca il modulo venv, installalo una sola volta con
`sudo apt install python3-venv`, poi esegui di nuovo `./build_deb.sh`.
La compressione del payload da ~1,4 GB (PySide6 + Chromium incluso) e il passo
piu lento e ne stampa la durata; il file `.deb` compare in `dist/` solo quando
e completo. Per una build molto piu veloce, che richiede dpkg >= 1.21.18 per
l'installazione, usa `DEB_COMPRESSION=zstd ./build_deb.sh`.

Non e consigliato compilare da un disco Windows montato in WSL (`/mnt/c/...` e
simili): quei filesystem non possono memorizzare i permessi Unix, quindi la
build lo rileva e prepara il pacchetto in `/tmp`. Per una build piu rapida e
affidabile, copia il progetto su un filesystem Linux come `~/sponsorscout`.

**Pacchetto Linux (Fedora / RHEL / openSUSE — RPM):**
```bash
./build_rpm.sh               # -> dist/sponsorscout-<versione>-1.<arch>.rpm
```
Stesse regole del `.deb`: esegui lo script come utente normale (**non usare
`sudo`**) e lascia che crei l'ambiente isolato `.build/rpm-venv`. Richiede
`rpmbuild` (`sudo dnf install rpm-build` su Fedora/RHEL, `sudo apt install rpm`
su Debian/Ubuntu/WSL, `sudo zypper install rpm-build` su openSUSE). Include
Playwright Chromium, esegue il self-check del binario e non strappa mai le
estensioni C incluse — esattamente come `build_deb.sh`. Il compressore del
payload viene sondato sulla macchina (di default xz veloce); per un pacchetto
piu piccolo dove tutti i target hanno rpm >= 4.14 usa
`RPM_COMPRESSION=zstd ./build_rpm.sh`. Anche questo script tocca `dist/` solo
con il proprio output, quindi `.exe`, `.deb` e `.rpm` possono convivere.

**Test:**
```bash
python -m pytest sponsorscout/tests
```

---

---

## Verifica e registro fix
- **Suite:** `python -m pytest sponsorscout/tests -q --continue-on-collection-errors`
  → **681 passed / 12 failed / 4 skipped**; i 12 fallimenti e i 4 skip sono il
  set preesistente documentato (baseline prima di questo intervento: 560/15/6).
- **Pin:** ogni fix di produzione arriva con un pin di regressione in
  `sponsorscout/tests/` — le suite del 2026-10-22 portano 103 pin di
  consistenza della raccolta, 9 pin di completezza assistita e 4 pin
  dell'indicatore di spunta.
- **Gate:** `tests/test_run20261016_fixes.py` (61 PASS / 0 FAIL),
  `tests/test_run20261016B_fixes.py` (62 PASS / 0 FAIL) e
  `tools/check_readme_anchors.py` (ogni link interno risolve).
- **Verifica live:** `live_verify/synth_board.py` +
  `live_verify/live_verify_synth.py` (consegnati con l'archivio dei fix)
  riproducono un portale sintetico con pager a finestra e href firmati in un
  harness a otto fasi — baseline, scorrimento finestra, challenge a metà run
  risolta e non risolta, falsa fine + parità CSV, clamp a fine elenco, soft
  denial e una finestra di rate-limit con sei rifiuti;
  `live_verify/live_verify_deep.py` dimostra un portale di 27 pagine.
- **Registro fix:** F-01…F-40 e le revisioni 1–13 sono in `FIXES_MANIFEST.md`
  (consegnato con l'archivio dei fix); punti salienti: verifica TLS
  ripristinata, frazioni del walker, profilo low-memory, adapter
  SmartRecruiters ed Elior, schema replica, indicatore di spunta (rev 3),
  consistenza della raccolta assistita e parità CSV (F-27…F-36), probe di
  falsa fine e contatori onesti (F-33…F-35c), cool-down e retry degli href
  negati (F-37…F-38), timestamp della riga run (F-39), startup per ambito
  (F-40).

## 📋 Requisiti

- Python 3.10 o successivo (per eseguire da sorgenti; gli installer non richiedono nulla)
- Runtime: **PySide6**, **requests**, **playwright** (`requirements.txt`)
- Playwright Chromium: `python -m playwright install chromium`
- Solo sviluppo/test: **pytest**, **pyinstaller** (`pip install ".[dev]"`)
- Pacchetto Linux: `python3`, `python3-venv` e `dpkg` (`sudo apt install python3-venv`); `rpmbuild` per il `.rpm` (`sudo dnf install rpm-build` / `sudo apt install rpm`)
- Opzionale: `SPONSORSCOUT_AUTO_INSTALL_BROWSERS=1` permette all'app di scaricare da sola Chromium quando manca (disattivato per impostazione predefinita)

---

## 📄 Licenza

MIT — vedi [LICENSE](LICENSE).
